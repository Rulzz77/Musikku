package com.musikku.app

import android.Manifest
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.content.ContentUris
import android.provider.MediaStore
import android.media.MediaMetadataRetriever
import android.os.Build
import android.annotation.TargetApi
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.graphics.drawable.Icon
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.util.Log
import android.content.Intent
import android.os.Bundle
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine

import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.StandardMessageCodec
import io.flutter.plugin.platform.PlatformView
import io.flutter.plugin.platform.PlatformViewFactory

import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat


private const val PIP_ACTION = "com.musikku.app.PIP_CONTROL"
private const val PIP_EXTRA_TYPE = "type"
private const val PIP_PREVIOUS = 1
private const val PIP_PLAY_PAUSE = 2
private const val PIP_NEXT = 3

// ============================================================
// YOUTUBE PLATFORM VIEW FACTORY
// ============================================================

class YoutubePlatformViewFactory :
    PlatformViewFactory(
        StandardMessageCodec.INSTANCE
    ) {

    override fun create(
        context: android.content.Context,
        viewId: Int,
        args: Any?
    ): PlatformView {

        Log.d(
            "MusikKuNative",
            "===================================="
        )

        Log.d(
            "MusikKuNative",
            "PLATFORM VIEW CREATE"
        )

        Log.d(
            "MusikKuNative",
            "viewId = $viewId"
        )

        Log.d(
            "MusikKuNative",
            "===================================="
        )

        return YoutubePlatformView(context)
    }
}


// ============================================================
// MAIN ACTIVITY
// ============================================================

class MainActivity : AudioServiceActivity() {

    private val audioEffectsController = AudioEffectsController()
    private lateinit var healthMonitor: AppHealthMonitor

    private var pendingFileResult: MethodChannel.Result? = null
    private var backupJsonWaiting: String = ""
    private var pendingFileRequestCode: Int = 0
    private var pendingLocalPermissionResult: MethodChannel.Result? = null

    companion object {

        private const val TAG =
            "MusikKuNative"

        const val METHOD_CHANNEL =
            "musikku/youtube_player"

        const val EVENT_CHANNEL =
            "musikku/youtube_player/events"

        private const val REQUEST_EXPORT_BACKUP = 9901
        private const val REQUEST_IMPORT_BACKUP = 9902

        const val LOCAL_METHOD_CHANNEL =
            "musikku/local_media"

        private const val REQUEST_LOCAL_AUDIO_PERMISSION = 6001

        // ====================================================
        // CHANNEL UNTUK SERVICE -> FLUTTER
        // ====================================================

        var notificationMethodChannel: MethodChannel? = null
        private var uncaughtHandlerInstalled = false

    }

    // Video dari notifikasi (live / video baru) yang diketuk sebelum Flutter siap.
    private var pendingNotificationVideo: Map<String, String>? = null

    /** Baca extra dari intent notifikasi; kembalikan null kalau bukan dari notifikasi. */
    private fun readNotificationVideo(intent: Intent?): Map<String, String>? {
        val videoId = intent?.getStringExtra(SubscriptionWatchWorker.EXTRA_VIDEO_ID).orEmpty()
        if (videoId.isEmpty()) return null
        val video = mapOf(
            "videoId" to videoId,
            "title" to (intent?.getStringExtra(SubscriptionWatchWorker.EXTRA_VIDEO_TITLE).orEmpty()),
            "channelTitle" to (intent?.getStringExtra(SubscriptionWatchWorker.EXTRA_VIDEO_CHANNEL).orEmpty())
        )
        // Hapus supaya tidak terbuka lagi saat Activity dibuat ulang (rotasi dll).
        intent?.removeExtra(SubscriptionWatchWorker.EXTRA_VIDEO_ID)
        return video
    }

    private fun currentNetworkTypeForApp(): String {
        return try {
            val manager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return "unknown"
            val network = manager.activeNetwork ?: return "offline"
            val capabilities = manager.getNetworkCapabilities(network) ?: return "offline"
            when {
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile"
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
                else -> "other"
            }
        } catch (_: Exception) {
            "unknown"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        healthMonitor = AppHealthMonitor.get(this)
        healthMonitor.start()
        if (!uncaughtHandlerInstalled) {
            val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
                healthMonitor.record("Crash", "Uncaught exception on ${thread.name}", throwable)
                previousHandler?.uncaughtException(thread, throwable)
            }
            uncaughtHandlerInstalled = true
        }
        pendingNotificationVideo = readNotificationVideo(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val video = readNotificationVideo(intent) ?: return
        val channel = notificationMethodChannel
        if (channel != null) {
            // Flutter sudah berjalan: langsung buka videonya.
            channel.invokeMethod("openVideoFromNotification", video)
        } else {
            pendingNotificationVideo = video
        }
    }


    // ========================================================
    // CONFIGURE FLUTTER ENGINE
    // ========================================================

    override fun configureFlutterEngine(
        flutterEngine: FlutterEngine
    ) {

        super.configureFlutterEngine(
            flutterEngine
        )


        Log.d(
            TAG,
            "===================================="
        )

        Log.d(
            TAG,
            "MUSIKKU NATIVE ENGINE AKTIF"
        )

        Log.d(
            TAG,
            "===================================="
        )


        // ====================================================
        // METHOD CHANNEL
        // ====================================================

        val methodChannel =
            MethodChannel(
                flutterEngine
                    .dartExecutor
                    .binaryMessenger,

                METHOD_CHANNEL
            )


        // ====================================================
        // SIMPAN CHANNEL
        // ====================================================

        notificationMethodChannel =
            methodChannel


        Log.d(
            TAG,
            "NOTIFICATION METHOD CHANNEL SIAP"
        )


        // ====================================================
        // METHOD CALL HANDLER
        // ====================================================

        methodChannel.setMethodCallHandler { call, result ->

            Log.d(
                TAG,
                "METHOD CHANNEL = ${call.method}"
            )


            when (call.method) {


                // ==================================================
                // LOAD VIDEO
                // ==================================================

                "configureBackgroundWatch" -> {
                    val enabled = call.argument<Boolean>("enabled") ?: false
                    val apiKey = call.argument<String>("apiKey").orEmpty()
                    val rawChannels = call.argument<List<*>>("channels").orEmpty()
                    val channels = rawChannels.mapNotNull { entry ->
                        (entry as? Map<*, *>)?.entries?.associate {
                            it.key.toString() to it.value.toString()
                        }
                    }
                    try {
                        SubscriptionWatchWorker.configure(applicationContext, enabled, apiKey, channels)
                        result.success(null)
                    } catch (e: Exception) {
                        Log.e(TAG, "CONFIGURE WATCH GAGAL", e)
                        result.error("WATCH_FAILED", e.message, null)
                    }
                }

                "takePendingVideo" -> {
                    val video = pendingNotificationVideo
                    pendingNotificationVideo = null
                    result.success(video)
                }

                "setPlayerUiVisible" -> {
                    val visible = call.argument<Boolean>("visible") ?: true
                    YoutubePlatformView.instance?.setPlayerUiVisible(visible)
                    result.success(null)
                }

                "setPlaybackQuality" -> {
                    val quality = call.argument<String>("quality")?.trim().orEmpty()
                    if (quality.isBlank()) {
                        result.error("INVALID_QUALITY", "Kualitas video kosong", null)
                        return@setMethodCallHandler
                    }
                    if (!YoutubePlatformView.requestQuality(quality)) {
                        result.error("INVALID_QUALITY", "Level kualitas tidak dikenal: $quality", null)
                        return@setMethodCallHandler
                    }
                    result.success(null)
                }

                "setDataSaverLevel" -> {
                    val level = call.argument<Int>("level") ?: 0
                    YoutubePlatformView.requestDataSaverLevel(level)
                    result.success(null)
                }

                "setCaptionSettings" -> {
                    val enabled = call.argument<Boolean>("enabled") ?: false
                    val language = call.argument<String>("language")?.trim().orEmpty().ifBlank { "id" }
                    YoutubePlatformView.requestCaptionSettings(enabled, language)
                    result.success(null)
                }

                "setVideoCrop" -> {
                    val zoom = call.argument<Double>("zoom") ?: 1.0
                    YoutubePlatformView.requestCrop(zoom)
                    result.success(null)
                }

                "setLandscapeSystemUi" -> {
                    val immersive = call.argument<Boolean>("immersive") ?: false
                    setLandscapeSystemUi(immersive)
                    result.success(null)
                }

                "loadVideo" -> {

                    val videoId =
                        call.argument<String>(
                            "videoId"
                        )

                    val startSeconds =
                        call.argument<Double>(
                            "startSeconds"
                        ) ?: 0.0


                    Log.d(
                        TAG,
                        "===================================="
                    )

                    Log.d(
                        TAG,
                        "MAINACTIVITY: LOAD VIDEO"
                    )

                    Log.d(
                        TAG,
                        "VIDEO ID = $videoId"
                    )

                    Log.d(
                        TAG,
                        "PLAYER INSTANCE = ${YoutubePlatformView.instance}"
                    )

                    Log.d(
                        TAG,
                        "===================================="
                    )


                    if (
                        videoId.isNullOrBlank()
                    ) {

                        Log.e(
                            TAG,
                            "LOAD VIDEO GAGAL: videoId kosong"
                        )

                        result.error(
                            "INVALID_ID",
                            "videoId kosong",
                            null
                        )

                        return@setMethodCallHandler
                    }



                    PlaybackService.stopLocalForYoutubeStatic()

                    val player =
                        YoutubePlatformView.instance


                    if (player == null) {

                        Log.e(
                            TAG,
                            "LOAD VIDEO GAGAL: PLAYER BELUM READY"
                        )

                        result.error(
                            "PLAYER_NOT_READY",
                            "Youtube player belum siap",
                            null
                        )

                        return@setMethodCallHandler
                    }


                    Log.d(
                        TAG,
                        "MEMANGGIL player.loadVideo()"
                    )


                    player.loadVideo(
                        videoId,
                        startSeconds.toFloat()
                    )


                    Log.d(
                        TAG,
                        "player.loadVideo() SELESAI"
                    )


                    result.success(
                        null
                    )
                }


                // ==================================================
                // PLAY
                // ==================================================

                "play" -> {

                    Log.d(
                        TAG,
                        "===================================="
                    )

                    Log.d(
                        TAG,
                        "MAINACTIVITY: METHOD PLAY DITERIMA"
                    )

                    Log.d(
                        TAG,
                        "PLAYER = ${YoutubePlatformView.instance}"
                    )

                    Log.d(
                        TAG,
                        "===================================="
                    )


                    if (PlaybackService.isLocalActiveStatic()) {
                        PlaybackService.playLocalStatic()
                        result.success(null)
                        return@setMethodCallHandler
                    }

                    val player =
                        YoutubePlatformView.instance


                    if (player == null) {

                        Log.e(
                            TAG,
                            "PLAY GAGAL: PLAYER NULL"
                        )

                    } else {

                        Log.d(
                            TAG,
                            "MEMANGGIL NATIVE PLAYER PLAY"
                        )

                        player.play()

                        Log.d(
                            TAG,
                            "NATIVE PLAYER PLAY SELESAI"
                        )
                    }


                    result.success(
                        null
                    )
                }


                // ==================================================
                // PAUSE
                // ==================================================

                "pause" -> {

                    Log.d(
                        TAG,
                        "===================================="
                    )

                    Log.d(
                        TAG,
                        "MAINACTIVITY: METHOD PAUSE DITERIMA"
                    )

                    Log.d(
                        TAG,
                        "PLAYER = ${YoutubePlatformView.instance}"
                    )

                    Log.d(
                        TAG,
                        "===================================="
                    )


                    if (PlaybackService.isLocalActiveStatic()) {
                        PlaybackService.pauseLocalStatic()
                        result.success(null)
                        return@setMethodCallHandler
                    }

                    val player =
                        YoutubePlatformView.instance


                    if (player == null) {

                        Log.e(
                            TAG,
                            "PAUSE GAGAL: PLAYER NULL"
                        )

                    } else {

                        Log.d(
                            TAG,
                            "MEMANGGIL NATIVE PLAYER PAUSE"
                        )

                        player.pause()

                        Log.d(
                            TAG,
                            "NATIVE PLAYER PAUSE SELESAI"
                        )
                    }


                    result.success(
                        null
                    )
                }


                // ==================================================
                // SEEK
                // ==================================================

                "seek" -> {

                    val seconds =
                        call.argument<Double>(
                            "seconds"
                        ) ?: 0.0


                    Log.d(
                        TAG,
                        "===================================="
                    )

                    Log.d(
                        TAG,
                        "MAINACTIVITY: SEEK"
                    )

                    Log.d(
                        TAG,
                        "SECONDS = $seconds"
                    )

                    Log.d(
                        TAG,
                        "PLAYER = ${YoutubePlatformView.instance}"
                    )

                    Log.d(
                        TAG,
                        "===================================="
                    )


                    if (PlaybackService.isLocalActiveStatic()) {
                        PlaybackService.seekLocalStatic(seconds)
                    } else {
                        YoutubePlatformView
                            .instance
                            ?.seek(
                                seconds.toFloat()
                            )
                    }


                    result.success(
                        null
                    )
                }


                // ==================================================
                // PLAYER VOLUME
                // ==================================================

                "setVolume" -> {
                    val percent =
                        call.argument<Int>("percent")?.coerceIn(0, 100) ?: 100

                    if (PlaybackService.isLocalActiveStatic()) {
                        PlaybackService.setLocalVolumeStatic(percent)
                    } else {
                        YoutubePlatformView.instance?.setVolume(percent)
                    }
                    result.success(null)
                }


                // ==================================================
                // LOCAL MUSIC PLAYER
                // ==================================================

                "loadLocal" -> {
                    val mediaId = call.argument<String>("mediaId")?.trim().orEmpty()
                    val title = call.argument<String>("title")?.trim().orEmpty()
                    val artist = call.argument<String>("artist")?.trim().orEmpty()
                    val uri = call.argument<String>("mediaUri")?.trim().orEmpty()
                    val startSeconds = call.argument<Double>("startSeconds") ?: 0.0
                    val durationSeconds = call.argument<Double>("durationSeconds") ?: 0.0

                    if (mediaId.isEmpty() || uri.isEmpty()) {
                        result.error("INVALID_LOCAL_MEDIA", "Data lagu lokal tidak lengkap", null)
                        return@setMethodCallHandler
                    }

                    YoutubePlatformView.instance?.deactivateForExternalPlayback()

                    PlaybackService.start(
                        this,
                        videoId = "local:$mediaId",
                        title = title.ifBlank { "Tanpa judul" },
                        artist = artist,
                        thumbnailUrl = "",
                        playing = true,
                        positionSeconds = startSeconds,
                        durationSeconds = durationSeconds,
                        sourceType = "local",
                        mediaUri = uri,
                    )
                    result.success(null)
                }


                // ==================================================
                // EQUALIZER PRESET
                // ==================================================

                "setEqualizerPreset" -> {
                    val preset = call.argument<String>("preset") ?: "Flat"
                    result.success(audioEffectsController.applyPreset(preset))
                }


                "getNetworkType" -> {
                    result.success(currentNetworkTypeForApp())
                }


                // ==================================================
                // PLAYER DEBUG SNAPSHOT
                // ==================================================

                "getPlayerDebugSnapshot" -> {
                    val player = YoutubePlatformView.instance
                    if (player == null) {
                        result.success(
                            mapOf(
                                "ready" to false,
                                "error" to "player_not_ready",
                                "videoId" to "",
                                "state" to "unknown",
                                "preferredQuality" to YoutubePlatformView.preferredQuality,
                                "actualQuality" to "unknown",
                                "captionsRequested" to YoutubePlatformView.preferredCaptionsEnabled,
                                "captionPreference" to YoutubePlatformView.preferredCaptionLanguage,
                                "captionTracks" to 0,
                                "captionLanguages" to emptyList<String>(),
                                "captionSelected" to "",
                                "captionTranslation" to "",
                                "captionActive" to false,
                            ),
                        )
                    } else {
                        player.getPlayerDebugSnapshot { snapshot ->
                            result.success(snapshot)
                        }
                    }
                }


                // ==================================================
                // CURRENT TIME
                // ==================================================

                "currentTime" -> {

                    val current = if (PlaybackService.isLocalActiveStatic()) {
                        PlaybackService.localCurrentTimeStatic().toFloat()
                    } else {
                        YoutubePlatformView
                            .instance
                            ?.currentTime()
                            ?: 0.0f
                    }


                    Log.d(
                        TAG,
                        "CURRENT TIME = $current"
                    )


                    result.success(
                        current.toDouble()
                    )
                }


                // ==================================================
                // NATIVE PLAYBACK SNAPSHOT BACKUP
                // ==================================================

                "getNativePlaybackSnapshot" -> {
                    val prefs =
                        getSharedPreferences(
                            "musikku_native_playback",
                            android.content.Context.MODE_PRIVATE,
                        )

                    result.success(
                        mapOf(
                            "videoId" to (prefs.getString("videoId", "") ?: ""),
                            "title" to (prefs.getString("title", "") ?: ""),
                            "artist" to (prefs.getString("artist", "") ?: ""),
                            "positionSeconds" to
                                (prefs.getLong("positionMs", 0L).toDouble() / 1000.0),
                            "durationSeconds" to
                                (prefs.getLong("durationMs", 0L).toDouble() / 1000.0),
                            "playing" to prefs.getBoolean("playing", false),
                        ),
                    )
                }


                "getHealthEvents" -> {
                    result.success(healthMonitor.events())
                }

                "clearHealthEvents" -> {
                    healthMonitor.clear()
                    result.success(null)
                }

                // ==================================================
                // BACKUP / RESTORE
                // ==================================================

                "exportBackup" -> {
                    val raw = call.argument<String>("json") ?: ""
                    pendingFileResult = result
                    pendingFileRequestCode = REQUEST_EXPORT_BACKUP
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/json"
                        putExtra(Intent.EXTRA_TITLE, "musikKu_backup.json")
                    }
                    try {
                        startActivityForResult(intent, REQUEST_EXPORT_BACKUP)
                    } catch (e: Exception) {
                        pendingFileResult = null
                        result.error("FILE_PICKER", e.message, null)
                    }

                    backupJsonWaiting = raw
                }

                "importBackup" -> {
                    pendingFileResult = result
                    pendingFileRequestCode = REQUEST_IMPORT_BACKUP
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/json"
                    }
                    try {
                        startActivityForResult(intent, REQUEST_IMPORT_BACKUP)
                    } catch (e: Exception) {
                        pendingFileResult = null
                        result.error("FILE_PICKER", e.message, null)
                    }
                }

                // ==================================================
                // START NOTIFICATION
                // ==================================================

                "startNotification" -> {

                    val videoId =
                        call.argument<String>(
                            "videoId"
                        ) ?: ""


                    val title =
                        call.argument<String>(
                            "title"
                        ) ?: "MusikKu"


                    val artist =
                        call.argument<String>(
                            "artist"
                        ) ?: ""


                    val thumbnailUrl =
                        call.argument<String>(
                            "thumbnailUrl"
                        ) ?: ""

                    val mediaUri =
                        call.argument<String>(
                            "mediaUri"
                        ) ?: ""


                    val playing =
                        call.argument<Boolean>(
                            "playing"
                        ) ?: false

                    val positionSeconds =
                        call.argument<Double>(
                            "positionSeconds"
                        ) ?: 0.0

                    val durationSeconds =
                        call.argument<Double>(
                            "durationSeconds"
                        ) ?: 0.0


                    Log.d(
                        TAG,
                        "===================================="
                    )

                    Log.d(
                        TAG,
                        "START NOTIFICATION"
                    )

                    Log.d(
                        TAG,
                        "TITLE = $title"
                    )

                    Log.d(
                        TAG,
                        "ARTIST = $artist"
                    )

                    Log.d(
                        TAG,
                        "PLAYING = $playing"
                    )

                    Log.d(
                        TAG,
                        "===================================="
                    )


                    PlaybackService.start(
                        this,
                        videoId,
                        title,
                        artist,
                        thumbnailUrl,
                        playing,
                        positionSeconds,
                        durationSeconds,
                        sourceType = if (videoId.startsWith("local:")) "local" else "youtube",
                        mediaUri = mediaUri,
                    )


                    result.success(
                        null
                    )
                }


                // ==================================================
                // UPDATE NOTIFICATION
                // ==================================================

                "updateNotification" -> {

                    val videoId =
                        call.argument<String>(
                            "videoId"
                        ) ?: ""


                    val title =
                        call.argument<String>(
                            "title"
                        ) ?: "MusikKu"


                    val artist =
                        call.argument<String>(
                            "artist"
                        ) ?: ""


                    val thumbnailUrl =
                        call.argument<String>(
                            "thumbnailUrl"
                        ) ?: ""

                    val mediaUri =
                        call.argument<String>(
                            "mediaUri"
                        ) ?: ""


                    val playing =
                        call.argument<Boolean>(
                            "playing"
                        ) ?: false

                    val positionSeconds =
                        call.argument<Double>(
                            "positionSeconds"
                        ) ?: 0.0

                    val durationSeconds =
                        call.argument<Double>(
                            "durationSeconds"
                        ) ?: 0.0


                    Log.d(
                        TAG,
                        "===================================="
                    )

                    Log.d(
                        TAG,
                        "UPDATE NOTIFICATION"
                    )

                    Log.d(
                        TAG,
                        "TITLE = $title"
                    )

                    Log.d(
                        TAG,
                        "ARTIST = $artist"
                    )

                    Log.d(
                        TAG,
                        "PLAYING = $playing"
                    )

                    Log.d(
                        TAG,
                        "===================================="
                    )


                    PlaybackService.start(
                        this,
                        videoId,
                        title,
                        artist,
                        thumbnailUrl,
                        playing,
                        positionSeconds,
                        durationSeconds,
                        sourceType = if (videoId.startsWith("local:")) "local" else "youtube",
                        mediaUri = mediaUri,
                    )


                    result.success(
                        null
                    )
                }


                // ==================================================
                // STOP NOTIFICATION
                // ==================================================

                "stopNotification" -> {

                    Log.d(
                        TAG,
                        "===================================="
                    )

                    Log.d(
                        TAG,
                        "STOP NOTIFICATION"
                    )

                    Log.d(
                        TAG,
                        "===================================="
                    )


                    val serviceIntent =
                        android.content.Intent(
                            this,
                            PlaybackService::class.java
                        )


                    stopService(
                        serviceIntent
                    )


                    result.success(
                        null
                    )
                }


                // ==================================================
                // UNKNOWN METHOD
                // ==================================================

                else -> {

                    Log.w(
                        TAG,
                        "METHOD TIDAK DIKENAL = ${call.method}"
                    )


                    result.notImplemented()
                }
            }
        }


        // ========================================================
        // LOCAL MEDIA CHANNEL
        // ========================================================

        Log.d(TAG, "REGISTER LOCAL MEDIA METHOD CHANNEL")

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            LOCAL_METHOD_CHANNEL,
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "hasLocalMusicPermission" -> {
                    result.success(hasLocalMusicPermission())
                }

                "requestLocalMusicPermission" -> {
                    if (hasLocalMusicPermission()) {
                        result.success(true)
                        return@setMethodCallHandler
                    }

                    val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        Manifest.permission.READ_MEDIA_AUDIO
                    } else {
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    }

                    pendingLocalPermissionResult = result
                    requestPermissions(arrayOf(permission), REQUEST_LOCAL_AUDIO_PERMISSION)
                }

                "scanLocalMusic" -> {
                    if (!hasLocalMusicPermission()) {
                        result.success(emptyList<Map<String, Any?>>())
                        return@setMethodCallHandler
                    }

                    result.success(scanLocalMusic())
                }

                "getLocalArtwork" -> {
                    val mediaId = call.argument<String>("mediaId")?.trim().orEmpty()
                    result.success(getLocalArtwork(mediaId))
                }

                else -> result.notImplemented()
            }
        }


        // ========================================================
        // EVENT CHANNEL
        // ========================================================

        Log.d(
            TAG,
            "REGISTER EVENT CHANNEL"
        )


        EventChannel(
            flutterEngine
                .dartExecutor
                .binaryMessenger,

            EVENT_CHANNEL

        ).setStreamHandler(

            object :
                EventChannel.StreamHandler {


                // ================================================
                // FLUTTER LISTEN
                // ================================================

                override fun onListen(
                    arguments: Any?,
                    events: EventChannel.EventSink?
                ) {

                    Log.d(
                        TAG,
                        "===================================="
                    )

                    Log.d(
                        TAG,
                        "EVENT CHANNEL: FLUTTER MULAI LISTEN"
                    )

                    Log.d(
                        TAG,
                        "EVENT SINK = $events"
                    )

                    Log.d(
                        TAG,
                        "===================================="
                    )


                    YoutubePlatformView
                        .eventSink = events
                    PlaybackService.eventSink = events
                }


                // ================================================
                // FLUTTER CANCEL LISTEN
                // ================================================

                override fun onCancel(
                    arguments: Any?
                ) {

                    Log.d(
                        TAG,
                        "===================================="
                    )

                    Log.d(
                        TAG,
                        "EVENT CHANNEL: FLUTTER STOP LISTEN"
                    )

                    Log.d(
                        TAG,
                        "===================================="
                    )


                    YoutubePlatformView
                        .eventSink = null
                    PlaybackService.eventSink = null
                }
            }
        )


        // ========================================================
        // REGISTER PLATFORM VIEW
        // ========================================================

        Log.d(
            TAG,
            "===================================="
        )

        Log.d(
            TAG,
            "REGISTER YOUTUBE PLATFORM VIEW"
        )

        Log.d(
            TAG,
            "VIEW TYPE = musikku/youtube_player"
        )

        Log.d(
            TAG,
            "===================================="
        )


        flutterEngine
            .platformViewsController
            .registry
            .registerViewFactory(

                "musikku/youtube_player",

                YoutubePlatformViewFactory()
            )


        Log.d(
            TAG,
            "YOUTUBE PLATFORM VIEW REGISTERED"
        )


        // ========================================================
        // NOTIFICATION PERMISSION
        // ========================================================

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.TIRAMISU
        ) {

            if (
                checkSelfPermission(
                    Manifest.permission
                        .POST_NOTIFICATIONS
                ) !=
                PackageManager.PERMISSION_GRANTED
            ) {

                Log.d(
                    TAG,
                    "REQUEST NOTIFICATION PERMISSION"
                )


                requestPermissions(

                    arrayOf(
                        Manifest.permission
                            .POST_NOTIFICATIONS
                    ),

                    5001
                )

            } else {

                Log.d(
                    TAG,
                    "NOTIFICATION PERMISSION SUDAH ADA"
                )
            }
        }
    }


    private fun hasLocalMusicPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun scanLocalMusic(): List<Map<String, Any?>> {
        val resolver = contentResolver
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.IS_MUSIC,
        )

        val result = mutableListOf<Map<String, Any?>>()

        val genreBySongId = mutableMapOf<Long, String>()
        run {
            val genreCollection = MediaStore.Audio.Genres.EXTERNAL_CONTENT_URI
            val genreProjection = arrayOf(
                MediaStore.Audio.Genres._ID,
                MediaStore.Audio.Genres.NAME,
            )
            resolver.query(genreCollection, genreProjection, null, null, null)?.use { genreCursor ->
                val gid = genreCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres._ID)
                val gname = genreCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres.NAME)
                while (genreCursor.moveToNext()) {
                    val genreId = genreCursor.getLong(gid)
                    val genreName = genreCursor.getString(gname)?.trim().orEmpty()
                    if (genreName.isEmpty()) continue
                    val members = MediaStore.Audio.Genres.Members.getContentUri("external", genreId)
                    val memberProjection = arrayOf(MediaStore.Audio.Genres.Members.AUDIO_ID)
                    resolver.query(members, memberProjection, null, null, null)?.use { memberCursor ->
                        val audioId = memberCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres.Members.AUDIO_ID)
                        while (memberCursor.moveToNext()) {
                            genreBySongId.putIfAbsent(memberCursor.getLong(audioId), genreName)
                        }
                    }
                }
            }
        }

        resolver.query(
            collection,
            projection,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 0",
            null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC",
        )?.use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idIndex)
                val uri = ContentUris.withAppendedId(collection, id).toString()
                result += mapOf(
                    "mediaId" to id.toString(),
                    "uri" to uri,
                    "title" to (cursor.getString(titleIndex) ?: "Tanpa judul"),
                    "artist" to (cursor.getString(artistIndex) ?: ""),
                    "album" to (cursor.getString(albumIndex) ?: ""),
                    "durationMs" to cursor.getLong(durationIndex),
                    "genre" to (genreBySongId[id] ?: ""),
                )
            }
        }

        return result
    }

    private fun getLocalArtwork(mediaId: String): ByteArray? {
        if (mediaId.isBlank()) return null

        val uri = ContentUris.withAppendedId(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            mediaId.toLongOrNull() ?: return null,
        )

        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            retriever.embeddedPicture
        } catch (e: Exception) {
            Log.d(TAG, "LOCAL ARTWORK ERROR: ${e.message}")
            null
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
                // no-op
            }
        }
    }


    private fun setLandscapeSystemUi(immersive: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        if (immersive) {
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode != REQUEST_LOCAL_AUDIO_PERMISSION) return

        val granted = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        pendingLocalPermissionResult?.success(granted)
        pendingLocalPermissionResult = null
    }


    override fun onStart() {
        super.onStart()
        YoutubePlatformView.setAppBackground(false)
        registerQualityNetworkCallback()
        YoutubePlatformView.instance?.onAppForeground()
        refreshPipParamsForPlayerState(force = true)
    }

    override fun onStop() {
        super.onStop()
        // Layar mati / app ke background: video tidak terlihat, kualitas
        // diturunkan kalau mode hemat data aktif. Audio tidak terpengaruh.
        YoutubePlatformView.setAppBackground(true)
        unregisterQualityNetworkCallback()
    }

    private var qualityNetworkCallback: ConnectivityManager.NetworkCallback? = null
    private var lastNetworkNotMetered: Boolean? = null

    private fun registerQualityNetworkCallback() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || qualityNetworkCallback != null) return
        try {
            val manager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onCapabilitiesChanged(
                    network: android.net.Network,
                    capabilities: NetworkCapabilities
                ) {
                    val notMetered =
                        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
                    if (lastNetworkNotMetered != notMetered) {
                        lastNetworkNotMetered = notMetered
                        YoutubePlatformView.instance?.reapplyQuality()
                    }
                }
            }
            manager.registerDefaultNetworkCallback(callback)
            qualityNetworkCallback = callback
        } catch (e: Exception) {
            Log.w(TAG, "Gagal mendaftarkan network callback", e)
        }
    }

    private fun unregisterQualityNetworkCallback() {
        val callback = qualityNetworkCallback ?: return
        qualityNetworkCallback = null
        try {
            val manager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            manager?.unregisterNetworkCallback(callback)
        } catch (_: Exception) {
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        Log.d(TAG, "ACTIVITY CONFIG CHANGED orientation=${newConfig.orientation}")
    }

    // ========================================================
    // PIP: tombol Sebelumnya / Jeda-Putar / Berikutnya
    // ========================================================

    private val pipHandler = Handler(Looper.getMainLooper())
    private var pipReceiverRegistered = false
    private var lastPipPlaying: Boolean? = null
    private var systemPipEntryScheduled = false
    private var lastPipEligibility: Boolean? = null

    private val pipReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val method = when (intent?.getIntExtra(PIP_EXTRA_TYPE, -1)) {
                PIP_PREVIOUS -> "notificationPrevious"
                PIP_PLAY_PAUSE -> "notificationPlayPause"
                PIP_NEXT -> "notificationNext"
                else -> return
            }
            notificationMethodChannel?.invokeMethod(method, null)
            // Beri waktu player mengganti state, lalu perbarui ikon jeda/putar.
            pipHandler.postDelayed({ refreshPipActions() }, 500L)
        }
    }

    // Memeriksa state player tiap ~0,8 detik selama PiP supaya ikon
    // jeda/putar ikut berubah (mis. video selesai atau lanjut sendiri).
    private val pipPoller = object : Runnable {
        override fun run() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            if (!isInPictureInPictureMode) return
            refreshPipActions()
            pipHandler.postDelayed(this, 800L)
        }
    }

    private fun isPipPlaying(): Boolean {
        val state = YoutubePlatformView.instance?.getCurrentPlaybackState() ?: return false
        return state == "playing" || state == "buffering"
    }

    private fun ensurePipReceiver() {
        if (pipReceiverRegistered) return
        val filter = IntentFilter(PIP_ACTION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(pipReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(pipReceiver, filter)
        }
        pipReceiverRegistered = true
    }

    private fun releasePipReceiver() {
        pipHandler.removeCallbacks(pipPoller)
        if (!pipReceiverRegistered) return
        try {
            unregisterReceiver(pipReceiver)
        } catch (_: Exception) {
        }
        pipReceiverRegistered = false
    }

    @TargetApi(Build.VERSION_CODES.O)
    private fun pipAction(
        iconRes: Int,
        title: String,
        type: Int
    ): RemoteAction {
        val intent = Intent(PIP_ACTION)
            .setPackage(packageName)
            .putExtra(PIP_EXTRA_TYPE, type)
        val pending = PendingIntent.getBroadcast(
            this,
            type,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return RemoteAction(
            Icon.createWithResource(this, iconRes),
            title,
            title,
            pending
        )
    }

    @TargetApi(Build.VERSION_CODES.O)
    private fun buildPipParams(autoEnterEnabled: Boolean = false): PictureInPictureParams {
        val playing = isPipPlaying()
        lastPipPlaying = playing
        val actions = listOf(
            pipAction(android.R.drawable.ic_media_previous, "Sebelumnya", PIP_PREVIOUS),
            pipAction(
                if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (playing) "Jeda" else "Putar",
                PIP_PLAY_PAUSE
            ),
            pipAction(android.R.drawable.ic_media_next, "Berikutnya", PIP_NEXT)
        )
        val builder = PictureInPictureParams.Builder()
            .setAspectRatio(Rational(16, 9))
            .setActions(actions)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setAutoEnterEnabled(autoEnterEnabled)
        }
        return builder.build()
    }

    /**
     * Keeps Android 12+ auto-enter PiP parameters up to date while a YouTube
     * video is active. This is intentionally called from player state changes,
     * not only from onUserLeaveHint(), because Android 12+ can enter PiP before
     * onUserLeaveHint is delivered.
     */
    @TargetApi(Build.VERSION_CODES.O)
    fun refreshPipParamsForPlayerState(force: Boolean = false) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || isFinishing) return
        val eligible = YoutubePlatformView.instance?.shouldEnterPictureInPicture() == true
        val playing = isPipPlaying()
        if (!force && lastPipEligibility == eligible && lastPipPlaying == playing) return
        lastPipEligibility = eligible
        try {
            setPictureInPictureParams(
                buildPipParams(
                    autoEnterEnabled = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && eligible
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "GAGAL MENYIAPKAN AUTO-ENTER PIP", e)
        }
    }

    @TargetApi(Build.VERSION_CODES.O)
    private fun refreshPipActions() {
        if (isFinishing || !isInPictureInPictureMode) return
        if (isPipPlaying() == lastPipPlaying) return
        try {
            setPictureInPictureParams(buildPipParams())
        } catch (e: Exception) {
            Log.e(TAG, "GAGAL MEMPERBARUI TOMBOL PIP", e)
        }
    }

    @TargetApi(Build.VERSION_CODES.O)
    private fun enterSystemPipIfPossible(onStarted: (() -> Unit)? = null): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
        if (isFinishing || isInPictureInPictureMode || systemPipEntryScheduled) return false

        val player = YoutubePlatformView.instance
        if (player?.shouldEnterPictureInPicture() != true) {
            return false
        }

        systemPipEntryScheduled = true
        Log.d(TAG, "MASUK ANDROID SYSTEM PIP LANGSUNG")
        notificationMethodChannel?.invokeMethod("youtubePipWillEnter", null)

        try {
            ensurePipReceiver()
            refreshPipParamsForPlayerState(force = true)
            // Use the parameterized API on all supported API levels.
            // The parameterless overload returns Unit on newer Kotlin stubs,
            // which caused the previous if-expression to infer Any and fail
            // compilation when used as a Boolean condition.
            val entered: Boolean = enterPictureInPictureMode(buildPipParams(false))
            Log.d(TAG, "ANDROID SYSTEM PIP ENTERED=$entered")
            if (entered) onStarted?.invoke()
            systemPipEntryScheduled = false
            return entered
        } catch (e: Exception) {
            systemPipEntryScheduled = false
            Log.e(TAG, "GAGAL MASUK ANDROID SYSTEM PIP", e)
            return false
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+ uses setAutoEnterEnabled(true). The system performs
            // the actual transition while leaving the app; do not call the
            // explicit enter API from this callback.
            refreshPipParamsForPlayerState(force = true)
            return
        }
        if (!enterSystemPipIfPossible()) {
            Log.d(TAG, "USER LEAVE HINT: system PiP tidak diperlukan")
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode)
        notificationMethodChannel?.invokeMethod("youtubePipChanged", isInPictureInPictureMode)
        Log.d(TAG, "YOUTUBE PIP = $isInPictureInPictureMode")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            pipHandler.removeCallbacks(pipPoller)
            if (isInPictureInPictureMode) {
                pipHandler.postDelayed(pipPoller, 800L)
            } else {
                releasePipReceiver()
                lastPipEligibility = null
            }
        }
    }

    // ========================================================
    // TEKANAN MEMORI (untuk diagnosa)
    // ========================================================

    override fun onTrimMemory(level: Int) {
        Log.w(TAG, "TRIM MEMORY level=$level")
        super.onTrimMemory(level)
    }

    // ========================================================
    // TOMBOL BACK DI HALAMAN UTAMA
    // ========================================================
    //
    // Player YouTube hidup di dalam Activity ini. Kalau Activity di-finish
    // (Back di halaman utama), player ikut mati dan musik berhenti walau
    // notifikasi ada. Jadi Back cukup memindahkan app ke background,
    // sama seperti tombol Home. Musik baru berhenti lewat tombol Stop di
    // notifikasi atau saat task di-swipe dari recent apps.

    override fun popSystemNavigator(): Boolean {
        if (enterSystemPipIfPossible()) {
            // Android System PiP sendiri yang menangani perpindahan task ke
            // jendela PiP; tidak perlu moveTaskToBack agar surface player tetap hidup.
            return true
        }

        moveTaskToBack(true)
        return true
    }

    // ========================================================
    // ACTIVITY DESTROY
    // ========================================================

    override fun onDestroy() {
        if (::healthMonitor.isInitialized) healthMonitor.stop()
        releasePipReceiver()
        audioEffectsController.release()

        Log.d(TAG, "MAIN ACTIVITY DESTROY (isFinishing=$isFinishing)")

        // Activity benar-benar ditutup (task di-swipe dari recent apps atau
        // Stop dari notifikasi): hentikan musik, lepas player, dan matikan service/notifikasi.
        // Kalau bukan finishing (mis. sistem membuat ulang Activity),
        // player dibiarkan supaya tidak putus.
        if (isFinishing) {

            YoutubePlatformView.instance?.release()

            stopService(
                android.content.Intent(
                    this,
                    PlaybackService::class.java
                )
            )

            notificationMethodChannel = null
        }

        YoutubePlatformView.eventSink = null

        super.onDestroy()
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        val pending = pendingFileResult ?: return
        pendingFileResult = null

        if (resultCode != RESULT_OK || data?.data == null) {
            pending.success(null)
            return
        }

        try {
            val uri = data.data!!
            if (requestCode == REQUEST_EXPORT_BACKUP) {
                contentResolver.openOutputStream(uri)?.use { output ->
                    output.write(backupJsonWaiting.toByteArray(Charsets.UTF_8))
                    output.flush()
                } ?: throw IllegalStateException("Tidak bisa membuka file tujuan")
                backupJsonWaiting = ""
                pending.success(true)
            } else if (requestCode == REQUEST_IMPORT_BACKUP) {
                val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: throw IllegalStateException("Tidak bisa membaca file backup")
                pending.success(raw)
            } else {
                pending.success(null)
            }
        } catch (e: Exception) {
            pending.error("FILE_IO", e.message, null)
        }
    }

}
