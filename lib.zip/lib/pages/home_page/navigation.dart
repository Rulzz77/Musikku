part of '../home_page.dart';

// Extension ini bagian dari _HomePageState; setState aman dipakai di sini.
// ignore_for_file: invalid_use_of_protected_member

/// Navigasi ke halaman lain, tombol Back, dan backup/restore.
extension _HomeNavigation on _HomePageState {
  /// Dipanggil saat notifikasi sistem (live / video baru) diketuk.
  void _openVideoFromNotification(Map<String, String> data) {
    if (!mounted) return;
    final id = data['videoId'] ?? '';
    if (id.isEmpty) return;
    unawaited(_openYoutubeVideo(YoutubeSearchResult(
      videoId: id,
      title: (data['title'] ?? '').isEmpty ? 'Video' : data['title']!,
      channelTitle: data['channelTitle'] ?? '',
      thumbnailUrl: '',
    )));
  }

  Future<void> _openYoutubeVideo(YoutubeSearchResult video) async {
    if (!mounted) return;
    final sameVideo = _currentVideo?.videoId == video.videoId &&
        !_restoredNeedsLoad;
    try {
      await SystemChrome.setPreferredOrientations(const [DeviceOrientation.portraitUp]);
      await WidgetsBinding.instance.endOfFrame;
    } catch (_) {}
    await _youtubeController.setPlayerUiVisible(true);
    if (!mounted) return;
    setState(() {
      _youtubeWatchVideo = video;
      _youtubePipMode = false;
      _youtubeSystemPipMode = false;
      _suppressAutoNextInPip = false;
      _youtubeLandscapeControlsVisible.value = false;
      _youtubeLandscapeDiscussionVisible.value = false;
    });
    _showLandscapeControls();
    if (sameVideo) {
      // Video yang sama sudah dimuat: jangan di-load ulang (posisi tidak
      // balik ke 0). Kalau sedang pause, cukup lanjutkan.
      if (!_nativeState.isEffectivelyPlaying) {
        try {
          await _youtubeController.playVideo();
        } catch (_) {}
      }
      return;
    }
    await _playVideo(video);
  }

  void _handleYoutubeWatchBack() {
    if (!mounted || _youtubeWatchVideo == null) return;
    final size = MediaQuery.sizeOf(context);
    if (size.width > size.height) {
      // Back dari player landscape: portrait dulu, jangan langsung keluar.
      unawaited(_toggleYoutubeLandscape());
      return;
    }
    unawaited(_closeYoutubeWatch());
  }

  /// Back dari halaman tonton: video tetap jalan dan tampil sebagai
  /// jendela PiP mengambang di atas beranda.
  Future<void> _closeYoutubeWatch() async {
    if (!mounted) return;
    final wasPlaying = _nativeState.isEffectivelyPlaying;
    final videoId = _currentVideo?.videoId;

    _nearEndAutoNextTimer?.cancel();
    _nearEndAutoNextTimer = null;
    _nearEndArmedVideoId = '';
    _autoNextRetryTimer?.cancel();
    _autoNextRetryTimer = null;

    // PiP in MusikKu adalah PiP IN-APP. Jangan membuat ulang AndroidView dan
    // jangan pause player saat permukaan video dipindah ke jendela kecil.
    try {
      await SystemChrome.setPreferredOrientations(const [DeviceOrientation.portraitUp]);
      await WidgetsBinding.instance.endOfFrame;
    } catch (_) {}

    if (!mounted) return;
    setState(() {
      _youtubeWatchVideo = null;
      _youtubeSystemPipMode = false;
      _youtubePipMode = _currentVideo != null;
      _suppressAutoNextInPip = _currentVideo != null;
      _pipControlsVisible = true;
      _youtubeLandscapeControlsVisible.value = false;
      _youtubeLandscapeDiscussionVisible.value = false;
    });
    _showPipControls();

    // Sembunyikan custom UI setelah AndroidView tetap berada pada element yang
    // sama. Kalau perubahan ukuran sempat membuat WebView pause, lanjutkan lagi
    // posisi yang sama tanpa reload video.
    await WidgetsBinding.instance.endOfFrame;
    await _youtubeController.setPlayerUiVisible(false);

    if (wasPlaying && mounted && videoId != null && _currentVideo?.videoId == videoId) {
      try {
        await _youtubeController.playVideo();
      } catch (_) {}
    }
  }

  /// Tombol PiP di halaman tonton: tutup halaman, video tetap jalan
  /// sebagai jendela mengambang.
  Future<void> _enterFloatingPip() async {
    if (_currentVideo == null || !mounted) return;
    final wasPlaying = _nativeState.isEffectivelyPlaying;
    final videoId = _currentVideo!.videoId;

    _nearEndAutoNextTimer?.cancel();
    _nearEndAutoNextTimer = null;
    _nearEndArmedVideoId = '';
    _autoNextRetryTimer?.cancel();
    _autoNextRetryTimer = null;

    setState(() {
      _youtubeWatchVideo = null;
      _youtubePipMode = true;
      _suppressAutoNextInPip = true;
      _pipControlsVisible = true;
      _youtubeLandscapeControlsVisible.value = false;
      _youtubeLandscapeDiscussionVisible.value = false;
    });
    _showPipControls();

    await WidgetsBinding.instance.endOfFrame;
    await _youtubeController.setPlayerUiVisible(false);

    if (wasPlaying && mounted && _currentVideo?.videoId == videoId) {
      try {
        await _youtubeController.playVideo();
      } catch (_) {}
    }
  }

  /// Buka lagi halaman tonton untuk video yang sedang diputar
  /// (dari PiP) tanpa memuat ulang videonya.
  void _openYoutubeWatchFromPlayer() {
    final video = _currentVideo;
    if (video == null || !mounted) return;
    unawaited(_youtubeController.setPlayerUiVisible(true));
    setState(() {
      _youtubeWatchVideo = video;
      _youtubePipMode = false;
      _suppressAutoNextInPip = false;
      _youtubeRepeatCurrent = false;
      _youtubeLandscapeControlsVisible.value = false;
      _youtubeLandscapeDiscussionVisible.value = false;
    });
    _showLandscapeControls();
  }

  Future<void> _showYoutubePlayerSettings(BuildContext context) async {
    if (!mounted) return;
    await showYoutubePlayerSettingsSheet(
      context: context,
      repeat: _youtubeRepeatCurrent,
      quality: _youtubeQuality,
      captionsEnabled: _youtubeCaptionsEnabled,
      captionLanguage: _youtubeCaptionLanguage,
      onToggleRepeat: _toggleYoutubeRepeatCurrent,
      onSetQuality: _setYoutubeQuality,
      onSetCaptions: _setYoutubeCaptions,
      onSetCaptionLanguage: _setYoutubeCaptionLanguage,
    );
  }

  /// Zoom player saat "Potong tepi video" aktif.
  double get _videoCropZoom => widget.settings.cropVideoBranding.value ? 1.12 : 1.0;

  void _applyVideoCrop() {
    unawaited(_youtubeController.setVideoCrop(_videoCropZoom));
  }

  Future<void> _restoreYoutubePlayerPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedQuality = prefs.getString(_youtubeQualityPrefKey);
      final savedCaptions = prefs.getBool(_youtubeCaptionsEnabledPrefKey);
      final savedLanguage = prefs.getString(_youtubeCaptionLanguagePrefKey);

      if (mounted) {
        setState(() {
          if (savedQuality != null &&
              savedQuality.isNotEmpty &&
              youtubeQualityOptions.any((o) => o.value == savedQuality)) {
            _youtubeQuality = savedQuality;
          }
          if (savedCaptions != null) {
            _youtubeCaptionsEnabled = savedCaptions;
          }
          if (savedLanguage != null && savedLanguage.trim().isNotEmpty) {
            _youtubeCaptionLanguage = savedLanguage.trim();
          }
        });
      }

      if (savedQuality != null &&
          savedQuality.isNotEmpty &&
          youtubeQualityOptions.any((o) => o.value == savedQuality)) {
        await _youtubeController.setPlaybackQuality(savedQuality);
      }
      await _youtubeController.setCaptionSettings(
        enabled: savedCaptions ?? false,
        language: (savedLanguage == null || savedLanguage.trim().isEmpty)
            ? 'id'
            : savedLanguage.trim(),
      );
    } catch (_) {
      // Default player preferences tetap dipakai.
    }
  }

  Future<void> _setYoutubeCaptions(bool enabled) async {
    final previousEnabled = _youtubeCaptionsEnabled;
    final previousLanguage = _youtubeCaptionLanguage;
    try {
      setState(() => _youtubeCaptionsEnabled = enabled);
      await _youtubeController.setCaptionSettings(
        enabled: enabled,
        language: _youtubeCaptionLanguage,
      );
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_youtubeCaptionsEnabledPrefKey, enabled);
      await prefs.setString(_youtubeCaptionLanguagePrefKey, _youtubeCaptionLanguage);
      if (mounted) {
        _toast(
          enabled
              ? 'Subtitle aktif: ${youtubeCaptionLabel(_youtubeCaptionLanguage)}'
              : 'Subtitle dimatikan',
          duration: const Duration(seconds: 1),
        );
        if (enabled) unawaited(_reportCaptionStatus());
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _youtubeCaptionsEnabled = previousEnabled;
          _youtubeCaptionLanguage = previousLanguage;
        });
        _toast('Gagal mengubah subtitle/terjemahan: $e');
      }
    }
  }

  /// Beri tahu pengguna kalau subtitle/terjemahan tidak bisa muncul. Penyebab
  /// paling umum: video musik tidak punya track subtitle sama sekali, jadi
  /// tidak ada yang bisa ditampilkan atau diterjemahkan YouTube.
  Future<void> _reportCaptionStatus() async {
    await Future<void>.delayed(const Duration(seconds: 5));
    if (!mounted || !_youtubeCaptionsEnabled) return;
    final snapshot = await _youtubeController.getPlayerDebugSnapshot();
    if (!mounted || snapshot.hasError) return;
    if (snapshot.captionTracks == 0) {
      _toast(
        'Video ini tidak punya subtitle, jadi tidak ada yang bisa diterjemahkan.',
        duration: const Duration(seconds: 4),
      );
    } else if (_youtubeCaptionLanguage.startsWith('auto:') &&
        snapshot.captionTranslation.isEmpty) {
      _toast(
        'YouTube belum menerapkan terjemahan untuk video ini.',
        duration: const Duration(seconds: 4),
      );
    }
  }

  Future<void> _setYoutubeCaptionLanguage(String language) async {
    final normalized = language.trim().isEmpty ? 'id' : language.trim();
    final previous = _youtubeCaptionLanguage;

    try {
      setState(() => _youtubeCaptionLanguage = normalized);

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_youtubeCaptionLanguagePrefKey, normalized);

      if (_youtubeCaptionsEnabled) {
        await _youtubeController.setCaptionSettings(
          enabled: true,
          language: normalized,
        );
      }

      if (mounted) {
        _toast('Bahasa subtitle: ${youtubeCaptionLabel(normalized)}');
        if (_youtubeCaptionsEnabled) unawaited(_reportCaptionStatus());
      }
    } catch (e) {
      if (mounted) {
        setState(() => _youtubeCaptionLanguage = previous);
        _toast('Gagal mengubah bahasa subtitle: $e');
      }
    }
  }

  /// Backward-compatible helper untuk bagian kode lama yang masih memanggil
  /// pemulihan kualitas saja.
  Future<void> _setYoutubeQuality(String quality) async {
    try {
      await _youtubeController.setPlaybackQuality(quality);
      if (mounted) setState(() => _youtubeQuality = quality);
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(_youtubeQualityPrefKey, quality);
      } catch (_) {}
      if (!mounted) return;
      _toast('Kualitas video: ${youtubeQualityLabel(quality)}');
      // YouTube yang memutuskan kualitas akhir (adaptif). Cek hasil nyatanya
      // beberapa detik kemudian supaya kelihatan kalau permintaan tidak diikuti.
      unawaited(Future<void>.delayed(const Duration(seconds: 5), () async {
        final snapshot = await _youtubeController.getPlayerDebugSnapshot();
        final actual = snapshot.actualQuality;
        if (!mounted || actual.isEmpty || actual == 'unknown') return;
        if (quality != 'default' && actual != quality) {
          _toast(
            'YouTube sekarang memutar ${youtubeQualityLabel(actual)} '
            '(diminta ${youtubeQualityLabel(quality)})',
          );
        }
      }));
    } catch (e) {
      if (mounted) _toast('Gagal mengubah kualitas: $e');
    }
  }

  void _toggleYoutubeRepeatCurrent() {
    setState(() => _youtubeRepeatCurrent = !_youtubeRepeatCurrent);
    _toast(_youtubeRepeatCurrent ? 'Repeat video aktif 🔂' : 'Repeat video dimatikan');
  }

  Future<void> _toggleYoutubeLandscape() async {
    if (!mounted || _youtubeOrientationChanging) return;

    _youtubeOrientationChanging = true;
    _youtubeLandscapeDiscussionVisible.value = false;
    _youtubeLandscapeControlsVisible.value = false;
    _youtubeLandscapeControlsTimer?.cancel();
    final size = MediaQuery.sizeOf(context);
    final currentlyLandscape = size.width > size.height;
    final orientations = currentlyLandscape
        ? const [DeviceOrientation.portraitUp]
        : const [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight];

    try {
      // Sembunyikan system bars secara native hanya untuk landscape. Flutter
      // target SDK 36 memakai edge-to-edge dan tidak dapat memaksa immersive
      // lewat SystemUiMode lama; native WindowInsetsController tetap bisa.
      if (!currentlyLandscape) {
        await _youtubeController.setLandscapeSystemUi(true);
      }

      await SystemChrome.setPreferredOrientations(orientations);

      await WidgetsBinding.instance.endOfFrame;
      await WidgetsBinding.instance.endOfFrame;
      await Future<void>.delayed(const Duration(milliseconds: 60));

      if (currentlyLandscape) {
        // Setelah kembali portrait, tampilkan lagi status/navigation bar.
        await _youtubeController.setLandscapeSystemUi(false);
      } else {
        // Re-apply once after the window has actually become landscape.
        await _youtubeController.setLandscapeSystemUi(true);
      }
      _showLandscapeControls();
    } catch (e) {
      if (mounted) {
        _toast('Gagal mengganti orientasi: $e');
      }
    } finally {
      _youtubeOrientationChanging = false;
    }
  }

  /// Buka halaman channel dari halaman tonton (ketuk nama channel).
  /// Video mengecil jadi PiP dan channel terbuka di hub, jadi Back dari video
  /// berikutnya kembali ke channel ini.
  void _openChannelPage(String channelId, String title) {
    if (_youtubeWatchVideo != null) unawaited(_closeYoutubeWatch());
    _hubController.openChannel(channelId, title: title);
  }

  Future<void> _rateYoutubeVideo(String videoId, String rating) async {
    try {
      final account = YoutubeAccountService.instance;
      await account.rateVideo(videoId, rating);
      if (mounted) _toast(rating == 'like' ? 'Ditandai suka.' : 'Ditandai tidak suka.');
    } catch (e) {
      if (mounted) _toast('Gagal memperbarui penilaian: $e');
    }
  }

  void _openArtist(String artist) {
    final name = artist.trim();
    if (name.isEmpty) return;

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ArtistPage(
          artist: name,
          searchService: _searchService,
          onPlay: (video) {
            _activeSource = _ListSource.radio;
            _radio.start('$name music');
            unawaited(_playVideo(video));
          },
          onLongPress: _showVideoMenu,
        ),
      ),
    );
  }

  /// Mengembalikan true kalau Back dipakai untuk "mundur" satu layar
  /// di dalam app. False = sudah di layar depan, biarkan app ke background.
  bool _handleBack() {
    // 0) Kalau halaman tonton masih landscape, Back pertama hanya mengembalikan
    // orientasi ke portrait. Back berikutnya baru menutup halaman tonton/PiP.
    if (_youtubeWatchVideo != null) {
      _handleYoutubeWatchBack();
      return true;
    }

    // 0b) Halaman channel terbuka di hub -> tutup, kembali ke hub.
    if (_hubController.handleBack()) {
      return true;
    }

    // 1) Keyboard / kolom cari sedang aktif.
    if (_searchFocusNode.hasFocus) {
      _searchFocusNode.unfocus();

      return true;
    }

    // 2) Sedang membuka isi satu playlist -> kembali ke daftar playlist.
    if (_showPlaylists && _openPlaylistId != null) {
      setState(() {
        _openPlaylistId = null;
      });

      return true;
    }

    // 3) Layar favorit / playlist -> kembali ke layar depan.
    if (_showFavorites || _showPlaylists) {
      setState(() {
        _showFavorites = false;
        _showPlaylists = false;
        _openPlaylistId = null;
      });

      return true;
    }

    // 4) Hasil pencarian -> bersihkan, kembali ke layar depan.
    if (_searchResults.isNotEmpty ||
        _errorMessage.isNotEmpty ||
        _isLoading) {
      _searchController.clear();

      setState(() {
        _searchResults = [];
        _errorMessage = '';
        _isLoading = false;
      });

      return true;
    }

    return false;
  }


}
