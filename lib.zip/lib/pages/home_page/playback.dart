part of '../home_page.dart';

// Extension ini bagian dari _HomePageState; setState aman dipakai di sini.
// ignore_for_file: invalid_use_of_protected_member

/// Inti pemutaran: memutar lagu, watchdog, penanganan gagal putar, dan lirik.
extension _HomePlayback on _HomePageState {
  Future<void> _loadLyrics(YoutubeSearchResult video) async {
    final requestId = ++_lyricsRequestId;

    if (video.isLocal) {
      if (mounted && requestId == _lyricsRequestId) {
        _playerUiState.value = _playerUiState.value.copyWith(
          lyrics: const <LyricLine>[],
          lyricsLoading: false,
          lyricsSynced: false,
        );
      }
      return;
    }

    final result = await LyricsService.getLyrics(
      title: video.title,
      artist: video.channelTitle,
    );

    // Lagu sudah ganti selama menunggu → buang hasilnya.
    if (!mounted || requestId != _lyricsRequestId) {
      return;
    }

    _playerUiState.value = _playerUiState.value.copyWith(
      lyrics: result?.lines ?? const <LyricLine>[],
      lyricsLoading: false,
      lyricsSynced: result?.synced ?? false,
    );
  }

  /// Putar [video] dari [list]. Kalau sumber playlist berubah
  /// (misalnya dari pencarian ke favorit), playlist aktif diganti.
  Future<void> _playVideo(
    YoutubeSearchResult video, {
    bool recordHistory = true,
    double? restorePosition,
    double? restoreDurationSeconds,
    bool autoPlay = true,
  }) async {
    final requestId = ++_playRequestId;

    _isChangingTrack = true;

    _radio.markPlayed(video);

    _playbackWatchdog?.cancel();

    _failureHandledFor = '';

    _lastHandledEndedVideoId = '';
    _autoNextRetries = 0;
    _autoNextRetryTimer?.cancel();
    _autoNextRetryTimer = null;
    _nearEndAutoNextTimer?.cancel();
    _nearEndAutoNextTimer = null;
    _nearEndArmedVideoId = '';

    final previous = _currentVideo;

    final sameVideo = previous?.videoId == video.videoId;

    // Catat lagu sebelumnya untuk tombol Previous.
    if (recordHistory && previous != null && !sameVideo) {
      _playHistory.add(previous);

      if (_playHistory.length > 50) {
        _playHistory.removeAt(0);
      }
    }

    // Lagu yang sedang diputar keluar dari shuffle pool.
    if (_playerUiState.value.isShuffle) {
      _shufflePool.removeWhere((item) => item.videoId == video.videoId);
    }

    if (mounted) {
      setState(() {
        _currentVideo = video;
        // Halaman tonton (judul, deskripsi, komentar) harus ikut lagu baru saat
        // Next / Previous / auto-next. Kuncinya memakai videoId, jadi halaman
        // dibangun ulang dan memuat detail video yang baru.
        if (_youtubeWatchVideo != null) _youtubeWatchVideo = video;
      });
    }

    // Preset EQ mengikuti track yang sedang diputar. Bila belum pernah diatur
    // untuk track ini, pakai preset default dari Settings.
    try {
      final trackPreset = await _storage.loadEqualizerPresetForTrack(video.videoId);
      if (requestId == _playRequestId) {
        _equalizerPreset = trackPreset;
        await _youtubeController.setEqualizerPreset(trackPreset);
        if (mounted) setState(() {});
      }
    } catch (e) {
      debugPrint('TRACK EQ RESTORE ERROR: $e');
    }

    if (!sameVideo) {
      _crossfadeFadingVideoId = '';
    }

    // Player native akan di-load sekarang, jadi lagu hasil restore tidak lagi
    // "menunggu load" — termasuk kalau user memilih lagu yang sama dengan
    // lagu terakhir. Kalau flag ini tertinggal, tombol Pause malah memuat ulang.
    _restoredNeedsLoad = false;

    if (!sameVideo) {
      _rememberRecentlyPlayed(video);

      // Lagu baru selalu dimulai dari posisi 0, kecuali ini adalah
      // pemulihan snapshot lagu terakhir saat aplikasi dibuka kembali.
      _pendingSavedPosition = restorePosition ?? 0.0;

      _lastPositionSaveAt =
          DateTime.fromMillisecondsSinceEpoch(0);
    }

    _nativeStateNotifier.value = NativeYoutubeState(
      playbackState: NativePlaybackState.unstarted,
      duration: Duration(
        milliseconds:
            ((restoreDurationSeconds ?? 0.0).clamp(0.0, 86400.0) * 1000)
                .round(),
      ),
      videoId: video.videoId,
    );

    final currentLyrics = _playerUiState.value.lyrics;
    final currentLyricsLoading = _playerUiState.value.lyricsLoading;
    final currentLyricsSynced = _playerUiState.value.lyricsSynced;

    _playerUiState.value = _playerUiState.value.copyWith(
      video: video,
      isFavorite: _isFavorite(video.videoId),
      isLiked: _likedIds.contains(video.videoId),
      isDisliked: _dislikedIds.contains(video.videoId),
      lyrics: sameVideo ? currentLyrics : const <LyricLine>[],
      lyricsLoading: sameVideo ? currentLyricsLoading : true,
      lyricsSynced: sameVideo ? currentLyricsSynced : false,
    );

    if (!sameVideo) {
      unawaited(_loadLyrics(video));
    }

    try {
      // Membatalkan fade lama sebelum menghitung transition baru. Tanpa ini,
      // fade-out lagu sebelumnya bisa selesai terlambat dan menurunkan volume
      // lagu yang baru saja dimulai.
      _cancelVolumeFade();

      final wasAutoFading = !sameVideo &&
          previous != null &&
          _crossfadeFadingVideoId == previous.videoId;

      final transitionPlaying = !sameVideo &&
          previous != null &&
          _crossfadeSeconds > 0 &&
          _nativeState.isEffectivelyPlaying &&
          restorePosition == null &&
          !wasAutoFading;

      if (transitionPlaying) {
        await _fadeVolume(
          from: 100,
          to: 0,
          duration: Duration(milliseconds: _crossfadeSeconds * 500),
        );
      }

      final safeRestorePosition =
          restorePosition != null && restorePosition.isFinite
              ? restorePosition.clamp(0.0, 86400.0).toDouble()
              : 0.0;

      final safeRestoreDuration =
          restoreDurationSeconds != null && restoreDurationSeconds.isFinite
              ? restoreDurationSeconds.clamp(0.0, 86400.0).toDouble()
              : _nativeState.duration.inMilliseconds / 1000.0;

      final hasRestorePosition = safeRestorePosition > 0;

      // Unified player: lagu lokal diputar oleh Media3, YouTube tetap memakai
      // platform view yang sudah ada. Keduanya berbagi state/notification/queue.
      if (video.isLocal) {
        if (previous != null && !previous.isLocal) {
          try {
            await _youtubeController.pauseVideo();
          } catch (_) {}
        }
        await _youtubeController.loadLocalTrack(
          mediaId: video.localMediaId.isNotEmpty
              ? video.localMediaId
              : video.videoId.replaceFirst('local:', ''),
          title: video.title,
          artist: video.channelTitle,
          mediaUri: video.mediaUri,
          startSeconds: hasRestorePosition ? safeRestorePosition : 0.0,
          durationSeconds: safeRestoreDuration,
        );
      } else {
        await _youtubeController.loadVideoById(
          videoId: video.videoId,
          startSeconds: hasRestorePosition ? safeRestorePosition : 0.0,
        );
      }

      if (transitionPlaying || wasAutoFading) {
        await _fadeVolume(
          from: 0,
          to: 100,
          duration: Duration(milliseconds: _crossfadeSeconds * 500),
        );
      } else {
        await _setPlayerVolume(100);
      }
      _crossfadeFadingVideoId = '';

      if (requestId != _playRequestId) {
        return;
      }

      if (autoPlay) {
        _armPlaybackWatchdog(video.videoId, requestId);
      }

      if (hasRestorePosition) {
        _pendingSavedPosition = safeRestorePosition;
        _lastPositionSaveAt = DateTime.now();
        await _storage.saveLastPlayed(
          video,
          positionSeconds: safeRestorePosition,
          durationSeconds: safeRestoreDuration,
        );

        if (!autoPlay) {
          // API native loadVideo memang autoplay. Hanya dipakai sebagai
          // safeguard bila caller meminta restore tanpa autoplay.
          await Future<void>.delayed(const Duration(milliseconds: 700));
          if (requestId == _playRequestId) {
            await _youtubeController.pauseVideo();
          }
        }

        if (mounted && safeRestorePosition >= 3) {
          _toast(
            'Melanjutkan dari ${_formatStoredPosition(safeRestorePosition)}',
            duration: const Duration(seconds: 2),
          );
        }
      } else if (!autoPlay) {
        await Future<void>.delayed(const Duration(milliseconds: 700));
        if (requestId == _playRequestId) {
          await _youtubeController.pauseVideo();
        }
      }
    } catch (e) {
      debugPrint('PLAY VIDEO ERROR: $e');

      _toast('Gagal memutar lagu: $e');
    } finally {
      if (requestId == _playRequestId) {
        _isChangingTrack = false;
      }
    }
  }

  //
  // Video bisa dihapus, diblokir embed, atau dibatasi umur. Dua jalur
  // deteksi: (1) native mengirim state 'error', (2) watchdog: 15 detik
  // setelah load tapi player tidak pernah playing / buffering.
  //

  void _armPlaybackWatchdog(String videoId, int requestId) {
    _playbackWatchdog?.cancel();

    _playbackWatchdog = Timer(const Duration(seconds: 15), () {
      if (!mounted || requestId != _playRequestId) {
        return;
      }

      if (_currentVideo?.videoId != videoId) {
        return;
      }

      final playback = _nativeState.playbackState;

      final stuck = playback == NativePlaybackState.unstarted ||
          playback == NativePlaybackState.unknown ||
          playback == NativePlaybackState.cued ||
          playback == NativePlaybackState.error;

      if (stuck) {
        unawaited(_handlePlaybackFailure(videoId));
      }
    });
  }

  Future<void> _handlePlaybackFailure(String videoId) async {
    final video = _currentVideo;

    if (video == null || video.videoId != videoId) {
      return;
    }

    // Satu lagu hanya diproses sekali (error native + watchdog bisa datang
    // berdekatan).
    if (_failureHandledFor == videoId) {
      return;
    }

    _failureHandledFor = videoId;

    _playbackWatchdog?.cancel();

    // Lagu yang tidak bisa diputar tidak perlu nongol di "Terakhir diputar".
    _recentlyPlayed.removeWhere((item) => item.videoId == videoId);
    unawaited(_storage.saveRecentlyPlayed(_recentlyPlayed));

    if (mounted) {
      setState(() {});
    }

    if (_consecutiveFailures >= 3) {
      _consecutiveFailures = 0;

      _toast('Beberapa lagu berturut-turut gagal diputar. Cek koneksi internet.');

      return;
    }

    _consecutiveFailures++;

    _toast('Lagu ini tidak bisa diputar, lompat ke berikutnya');

    await _next();
  }
}
