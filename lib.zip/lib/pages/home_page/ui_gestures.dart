part of '../home_page.dart';

extension _HomeYoutubeGestures on _HomePageState {
    void _showLandscapeControls() {
      if (!mounted) return;
      _youtubeLandscapeControlsTimer?.cancel();
      _youtubeLandscapeControlsVisible.value = true;
      _youtubeLandscapeControlsTimer = Timer(const Duration(seconds: 4), () {
        if (mounted) {
          _youtubeLandscapeControlsVisible.value = false;
        }
      });
    }
    void _toggleYoutubeControls() {
      if (!mounted || _youtubeWatchVideo == null) return;
      if (_youtubeLandscapeControlsVisible.value) {
        _youtubeLandscapeControlsTimer?.cancel();
        _youtubeLandscapeControlsVisible.value = false;
      } else {
        _showLandscapeControls();
      }
    }
    void _onYoutubePointerDown(PointerDownEvent event) {
      if (!mounted || _youtubeWatchVideo == null || _youtubeSystemPipMode) return;
      _youtubePointerDragStarted = false;
      _youtubePointerTotalDy = 0.0;
      _youtubePointerTotalDx = 0.0;
    }

    void _onYoutubePointerMove(PointerMoveEvent event) {
      if (!mounted || _youtubeWatchVideo == null || _youtubeSystemPipMode) return;

      _youtubePointerTotalDy += event.delta.dy;
      _youtubePointerTotalDx += event.delta.dx;

      final isLandscapeNow = MediaQuery.sizeOf(context).width > MediaQuery.sizeOf(context).height;
      if (isLandscapeNow || _youtubePointerDragStarted) {
        if (_youtubePointerDragStarted && !isLandscapeNow) {
          _youtubeTapDebounceTimer?.cancel();
          _handlePortraitSwipeDrag(event.delta.dy);
        }
        return;
      }

      final mostlyVertical = _youtubePointerTotalDy.abs() > _youtubePointerTotalDx.abs();
      if (mostlyVertical && _youtubePointerTotalDy.abs() >= 8.0) {
        _youtubePointerDragStarted = true;
        _youtubeTapDebounceTimer?.cancel();
        _handlePortraitSwipeDrag(event.delta.dy);
      }
    }

    void _onYoutubePointerUp(PointerUpEvent event) {
      if (!mounted || _youtubeWatchVideo == null || _youtubeSystemPipMode) return;

      if (_youtubePointerDragStarted) {
        _youtubePointerDragStarted = false;
        _youtubeLastTapUpAt = null;
        _youtubePointerTotalDy = 0.0;
        _youtubePointerTotalDx = 0.0;
        _finishPortraitSwipe();
        return;
      }

      final now = DateTime.now();
      final previousTap = _youtubeLastTapUpAt;
      final previousPosition = _youtubeLastDoubleTapLocalPosition;
      final isSecondTap = previousTap != null &&
          now.difference(previousTap).inMilliseconds <= 280 &&
          previousPosition != null &&
          (event.localPosition - previousPosition).distance <= 72.0;

      _youtubeLastDoubleTapLocalPosition = event.localPosition;
      _youtubeLastTapUpAt = now;

      if (isSecondTap) {
        _youtubeTapDebounceTimer?.cancel();
        _youtubeLastTapUpAt = null;
        _handleYoutubeDoubleTapSeek();
      } else {
        _youtubeTapDebounceTimer?.cancel();
        _youtubeTapDebounceTimer = Timer(const Duration(milliseconds: 220), () {
          if (mounted) _toggleYoutubeControls();
        });
      }

      _youtubePointerTotalDy = 0.0;
      _youtubePointerTotalDx = 0.0;
    }

    void _onYoutubePointerCancel(PointerCancelEvent event) {
      if (!mounted) return;
      _youtubeTapDebounceTimer?.cancel();
      _youtubePointerDragStarted = false;
      _youtubeLastTapUpAt = null;
      _youtubePointerTotalDy = 0.0;
      _youtubePointerTotalDx = 0.0;
      _cancelPortraitSwipe();
    }

    void _handleYoutubeDoubleTapSeek() {
      if (!mounted || _youtubeWatchVideo == null || _youtubeSystemPipMode) return;
      final state = _nativeStateNotifier.value;
      if (state.duration <= Duration.zero) return;

      final tapX = _youtubeLastDoubleTapLocalPosition?.dx ?? 0;
      final size = MediaQuery.sizeOf(context);
      final playerWidth = size.width;
      final seekForward = tapX >= playerWidth * 0.5;
      const deltaSeconds = 10.0;
      final current = state.position.inMilliseconds / 1000.0;
      final duration = state.duration.inMilliseconds / 1000.0;
      final next = (current + (seekForward ? deltaSeconds : -deltaSeconds))
          .clamp(0.0, duration)
          .toDouble();

      _youtubeSeekFeedbackTimer?.cancel();
      _updateHomeState(() => _youtubeSeekFeedbackText = seekForward ? '+10 detik' : '-10 detik');
      _youtubeSeekFeedbackTimer = Timer(const Duration(milliseconds: 800), () {
        if (mounted) _updateHomeState(() => _youtubeSeekFeedbackText = null);
      });
      _showLandscapeControls();
      unawaited(_youtubeController.seekTo(seconds: next));
    }

    void _handlePortraitSwipeDrag(double dy) {
      final size = MediaQuery.sizeOf(context);
      final isLandscapeNow = size.width > size.height;
      if (!mounted || _youtubeWatchVideo == null || isLandscapeNow) return;

      _youtubePortraitSwipeDragging = true;
      final next = _youtubePortraitSwipeDy + dy;
      // Sedikit resistensi setelah titik nyaman agar tarikan tetap terasa halus
      // dan video tidak "loncat" ketika jari melewati batas.
      final adjusted = next > 220.0
          ? 220.0 + ((next - 220.0) * 0.16)
          : next;
      _youtubePortraitSwipeDy = adjusted.clamp(0.0, 250.0).toDouble();
      // Tanpa _updateHomeState(): _youtubeSwipeDyNotifier sudah memicu rebuild ringan.
    }

    void _finishPortraitSwipe() {
      if (!mounted || _youtubeWatchVideo == null) return;

      final shouldOpenPip = _youtubePortraitSwipeDy >= 132.0;
      _youtubePortraitSwipeDragging = false;

      if (shouldOpenPip) {
        _youtubePortraitSwipeDy = 0.0;
        _updateHomeState(() {});
        unawaited(_enterFloatingPip());
        return;
      }

      // AnimatedPositioned/AnimatedScale menangani snap-back secara halus.
      _youtubePortraitSwipeDy = 0.0;
      _updateHomeState(() {});
    }

    void _cancelPortraitSwipe() {
      if (!mounted) return;
      _youtubePortraitSwipeDragging = false;
      _youtubePortraitSwipeDy = 0.0;
      _updateHomeState(() {});
    }

}
