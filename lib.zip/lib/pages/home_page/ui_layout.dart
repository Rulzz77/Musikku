part of '../home_page.dart';

// Layout utama HomePage dipisahkan dari gesture/player overlay agar perubahan
// layout tidak ikut menyentuh logika gesture dan kontrol player.
extension _HomeUiLayout on _HomePageState {
    Widget _buildScaffold(BuildContext context) {
      final size = MediaQuery.sizeOf(context);
      final watch = _youtubeWatchVideo;
      final isLandscapeWatch = watch != null && size.width > size.height;
      final playerHeight = size.width * 9 / 16;
      final topInset = MediaQuery.paddingOf(context).top;
      final double pipWidth =
          (size.width * 0.58).clamp(210.0, 280.0).toDouble();
      final double pipHeight = pipWidth * 9 / 16;
      final safeBottom = MediaQuery.paddingOf(context).bottom;
      final double pipMinTop = topInset + 10.0;
      final double pipMaxTop =
          (size.height - pipHeight - safeBottom - 10.0)
              .clamp(pipMinTop, size.height)
              .toDouble();

      // Posisi awal PiP: pojok kanan atas, sedikit di bawah status bar.
      // Nilainya dibaca ValueNotifier agar drag tidak rebuild seluruh HomePage.
      final defaultPipPosition = Offset(
        size.width - pipWidth - 12.0,
        pipMinTop + 54.0,
      );

      final pipActive = watch == null && _youtubePipMode;
      final systemPipActive = _youtubeSystemPipMode;

      return Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: Stack(
          children: [
            // PENTING: YoutubeHub sengaja TETAP mounted ketika membuka halaman
            // tonton. Dulu Hub dilepas dari widget tree lalu dibuat ulang saat
            // Back, sehingga restore/auth ikut jalan lagi. Offstage menjaga State
            // dan sesi yang sedang aktif tetap hidup.
            Positioned.fill(
              child: IgnorePointer(
                // Hub hanya boleh menolak sentuhan saat halaman tonton menutupinya.
                ignoring: watch != null || systemPipActive,
                child: ValueListenableBuilder<double>(
                  valueListenable: _youtubeSwipeDyNotifier,
                  // child dibuat sekali -> Hub TIDAK ikut rebuild saat swipe.
                  child: RepaintBoundary(
                    child: YoutubeHub(
                      controller: _hubController,
                      onPlay: _openYoutubeVideo,
                      onClose: () {},
                      bottomInset: 0,
                      watchProgress: _watchProgress,
                      watchDuration: _watchDuration,
                      recentlyPlayed: _recentlyPlayed,
                      favorites: _favorites,
                      currentVideoId: _currentVideo?.videoId,
                      onStartRadio: _startRadioFromVideo,
                      onSearchQueryChanged: (query) {
                        _lastSearchQuery = query.trim();
                      },
                      settings: widget.settings,
                    ),
                  ),
                  builder: (context, swipeDy, hub) {
                    final hubOpacity = watch == null
                        ? 1.0
                        : (!isLandscapeWatch && !systemPipActive)
                            ? (swipeDy / 140.0).clamp(0.0, 1.0).toDouble()
                            : 0.0;
                    return AnimatedOpacity(
                      // Saat jari menyeret, ikuti langsung (tanpa animasi 140ms
                      // yang di-restart tiap frame).
                      duration: _youtubePortraitSwipeDragging
                          ? Duration.zero
                          : const Duration(milliseconds: 140),
                      curve: Curves.easeOutCubic,
                      opacity: hubOpacity,
                      child: Transform.translate(
                        offset: Offset(0, watch != null && !isLandscapeWatch ? swipeDy * 0.18 : 0),
                        child: hub,
                      ),
                    );
                  },
                ),
              ),
            ),

            // SATU PlatformView native untuk semua mode.
            // Jangan memindahkan AndroidView ke cabang widget yang berbeda saat
            // masuk PiP/landscape: PlatformView bisa dilepas/dibuat ulang dan
            // playback ikut putus.
            if (_currentVideo != null && !_currentVideo!.isLocal)
              ValueListenableBuilder<bool>(
                valueListenable: _youtubeLandscapeDiscussionVisible,
                builder: (context, discussionVisible, _) {
                  return ValueListenableBuilder<Offset?>(
                    valueListenable: _youtubePipPosition,
                    builder: (context, position, _) {
                      // Ukuran window Android dapat berubah sesaat ketika
                      // masuk/keluar System PiP. Jangan pernah memberikan min
                      // > max ke num.clamp(), karena Dart akan melempar
                      // `Invalid argument(s): 8.0`.
                      final maxPipLeft =
                          max(8.0, size.width - pipWidth - 8.0);
                      final safePipMaxTop =
                          max(pipMinTop, pipMaxTop);
                      final pipLeft = (position ?? defaultPipPosition)
                          .dx
                          .clamp(8.0, maxPipLeft)
                          .toDouble();
                      final pipTop = (position ?? defaultPipPosition)
                          .dy
                          .clamp(pipMinTop, safePipMaxTop)
                          .toDouble();

                      // Rebuild HANYA subtree player saat swipe (bukan seluruh HomePage).
                      return ListenableBuilder(
                        listenable: _youtubeSwipeDyNotifier,
                        builder: (context, _) {
                      final isFloating = pipActive;
                      final surfaceVisible = watch != null || isFloating || systemPipActive;
                      final hiddenWidth = 320.0;
                      final hiddenHeight = 180.0;

                      // Saat komentar dibuka di landscape, video mendapatkan area
                      // sendiri di sisi kiri. Video tetap 16:9 dan tidak dipotong;
                      // hanya lebarnya yang mengikuti area yang tersisa.
                      final discussionPanelWidth =
                          (size.width * 0.38).clamp(320.0, 440.0).toDouble();
                      final landscapeAvailableWidth =
                          isLandscapeWatch && discussionVisible
                              ? (size.width - discussionPanelWidth)
                                  .clamp(1.0, size.width)
                                  .toDouble()
                              : size.width;
                      final effectiveLandscapeWidth =
                          landscapeAvailableWidth
                              .clamp(1.0, size.height * 16 / 9)
                              .toDouble();
                      final effectiveLandscapeHeight =
                          effectiveLandscapeWidth * 9 / 16;
                      final effectiveLandscapeLeft =
                          isLandscapeWatch && discussionVisible
                              ? (landscapeAvailableWidth - effectiveLandscapeWidth) / 2
                              : (size.width - effectiveLandscapeWidth) / 2;
                      final effectiveLandscapeTop =
                          (size.height - effectiveLandscapeHeight) / 2;

                      final playerLeft = !surfaceVisible
                          ? 0.0
                          : systemPipActive
                              ? 0.0
                              : isFloating
                                  ? pipLeft
                                  : isLandscapeWatch
                                      ? effectiveLandscapeLeft
                                      : 0.0;
                      final portraitDragDy = (!isLandscapeWatch && watch != null && !isFloating && !systemPipActive)
                          ? _youtubePortraitSwipeDy
                          : 0.0;
                      final playerTop = !surfaceVisible
                          ? 0.0
                          : systemPipActive
                              ? 0.0
                              : isFloating
                                  ? pipTop
                                  : isLandscapeWatch
                                      ? effectiveLandscapeTop
                                      : topInset + portraitDragDy;
                      final playerWidth = !surfaceVisible
                          ? hiddenWidth
                          : systemPipActive
                              ? size.width
                              : isFloating
                                  ? pipWidth
                                  : isLandscapeWatch
                                      ? effectiveLandscapeWidth
                                      : size.width;
                      final playerHeight = !surfaceVisible
                          ? hiddenHeight
                          : systemPipActive
                              ? size.height
                              : isFloating
                                  ? pipHeight
                                  : isLandscapeWatch
                                      ? effectiveLandscapeHeight
                                      : size.width * 9 / 16;
                      final portraitDragProgress = (!isLandscapeWatch && watch != null)
                          ? (_youtubePortraitSwipeDy / 220.0).clamp(0.0, 1.0).toDouble()
                          : 0.0;
                      // Skala kecil memberi feedback visual seperti mini-player YouTube.
                      // Hanya subtree player yang rebuild saat drag, jadi efek ini
                      // tetap ringan walaupun AndroidView/WebView berada di dalamnya.
                      const swipeShrink = 0.28;
                      final portraitScale = 1.0 - (swipeShrink * portraitDragProgress);
                      final portraitCornerRadius = 10.0 + (10.0 * portraitDragProgress);

                      return AnimatedPositioned(
                        key: const ValueKey('youtube-player-surface'),
                        duration: _youtubePortraitSwipeDragging
                            ? Duration.zero
                            : const Duration(milliseconds: 220),
                        curve: Curves.easeOutCubic,
                        left: playerLeft,
                        top: playerTop,
                        width: playerWidth,
                        height: playerHeight,
                        child: IgnorePointer(
                         ignoring: !surfaceVisible,
                         child: AnimatedOpacity(
                          duration: const Duration(milliseconds: 180),
                          opacity: surfaceVisible ? 1.0 : 0.01,
                          child: AnimatedScale(
                            scale: isFloating ? 1.0 : portraitScale,
                            alignment: Alignment.topCenter,
                            duration: _youtubePortraitSwipeDragging
                                ? Duration.zero
                                : const Duration(milliseconds: 220),
                            curve: Curves.easeOutCubic,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(
                                isFloating || portraitDragProgress <= 0
                                    ? (isFloating ? 14 : 0)
                                    : portraitCornerRadius,
                              ),
                              child: Stack(
                              fit: StackFit.expand,
                              children: [
                                // Semua interaksi player sekarang dimiliki Flutter.
                                // AndroidView sengaja dibuat non-interactive supaya WebView
                                // tidak mencuri gesture tap/drag dari kontrol MusikKu.
                                Listener(
                                  behavior: HitTestBehavior.opaque,
                                  onPointerDown: _onYoutubePointerDown,
                                  onPointerMove: _onYoutubePointerMove,
                                  onPointerUp: _onYoutubePointerUp,
                                  onPointerCancel: _onYoutubePointerCancel,
                                  child: HiddenYoutubePlayer(
                                    visible: surfaceVisible,
                                    interactive: false,
                                    width: playerWidth,
                                    height: playerHeight,
                                  ),
                                ),
                                // Tutup overlay "video lainnya" milik YouTube saat pause
                                // dengan thumbnail. Tidak menerima sentuhan.
                                if (surfaceVisible && !systemPipActive)
                                  Positioned.fill(
                                    child: IgnorePointer(
                                      child: ValueListenableBuilder<bool>(
                                        valueListenable: widget.settings.hidePauseOverlay,
                                        builder: (context, hideOverlay, _) {
                                          if (!hideOverlay) return const SizedBox.shrink();
                                          return ValueListenableBuilder<NativeYoutubeState>(
                                            valueListenable: _nativeStateNotifier,
                                            builder: (context, nativeState, _) {
                                              final showCover = nativeState.isPaused &&
                                                  nativeState.requestedPlaying != true &&
                                                  nativeState.videoId.isNotEmpty;
                                              return AnimatedOpacity(
                                                duration: const Duration(milliseconds: 120),
                                                opacity: showCover ? 1.0 : 0.0,
                                                child: showCover
                                                    ? ColoredBox(
                                                        color: Colors.black,
                                                        child: Image.network(
                                                          'https://i.ytimg.com/vi/${nativeState.videoId}/hqdefault.jpg',
                                                          fit: BoxFit.cover,
                                                          width: double.infinity,
                                                          height: double.infinity,
                                                          errorBuilder: (_, _, _) => const SizedBox.expand(),
                                                        ),
                                                      )
                                                    : const SizedBox.shrink(),
                                              );
                                            },
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                if (watch != null && !isFloating && !systemPipActive)
                                  Positioned.fill(
                                    child: ValueListenableBuilder<bool>(
                                      valueListenable: _youtubeLandscapeControlsVisible,
                                      builder: (context, controlsVisible, _) {
                                        if (!controlsVisible) return const SizedBox.shrink();

                                        return Stack(
                                          fit: StackFit.expand,
                                          children: [
                                            // Saat kontrol sedang tampil, layer kontrol ini menutupi seluruh
                                            // permukaan player. GestureDetector yang berada di bawahnya tidak
                                            // akan ikut menerima tap. Karena itu sediakan hit layer sendiri
                                            // sebagai child paling belakang; tombol-tombol di atasnya tetap
                                            // menerima tap mereka masing-masing.
                                            Positioned.fill(
                                              child: Listener(
                                                behavior: HitTestBehavior.opaque,
                                                onPointerDown: _onYoutubePointerDown,
                                                onPointerMove: _onYoutubePointerMove,
                                                onPointerUp: _onYoutubePointerUp,
                                                onPointerCancel: _onYoutubePointerCancel,
                                                child: const SizedBox.expand(),
                                              ),
                                            ),
                                            _youtubeWatchHeader(
                                              context,
                                              watch,
                                              landscape: isLandscapeWatch,
                                            ),
                                            Positioned.fill(
                                              child: Align(
                                                alignment: isLandscapeWatch
                                                    ? Alignment.center
                                                    : const Alignment(0, 0.16),
                                                child: ValueListenableBuilder<NativeYoutubeState>(
                                                  valueListenable: _nativeStateNotifier,
                                                  builder: (context, nativeState, _) {
                                                    final playing = nativeState.isEffectivelyPlaying;
                                                    return Row(
                                                      mainAxisSize: MainAxisSize.min,
                                                      children: [
                                                        _videoOverlayButton(
                                                          icon: Icons.skip_previous_rounded,
                                                          tooltip: 'Sebelumnya',
                                                          size: 44,
                                                          onTap: () => unawaited(_previous()),
                                                        ),
                                                        const SizedBox(width: 18),
                                                        _videoOverlayButton(
                                                          icon: playing
                                                              ? Icons.pause_rounded
                                                              : Icons.play_arrow_rounded,
                                                          tooltip: playing ? 'Jeda' : 'Putar',
                                                          size: 54,
                                                          onTap: () => unawaited(_togglePlayPause()),
                                                        ),
                                                        const SizedBox(width: 18),
                                                        _videoOverlayButton(
                                                          icon: Icons.skip_next_rounded,
                                                          tooltip: 'Berikutnya',
                                                          size: 44,
                                                          onTap: () => unawaited(_next()),
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 8,
                                              right: 8,
                                              bottom: isLandscapeWatch ? 8 : 4,
                                              child: ValueListenableBuilder<NativeYoutubeState>(
                                                valueListenable: _nativeStateNotifier,
                                                builder: (context, nativeState, _) =>
                                                    _youtubeSeekControls(nativeState),
                                              ),
                                            ),
                                            if (_youtubeSeekFeedbackText != null)
                                              Positioned.fill(
                                                child: IgnorePointer(
                                                  child: Center(
                                                    child: Material(
                                                      color: Colors.black.withValues(alpha: 0.58),
                                                      borderRadius: BorderRadius.circular(24),
                                                      child: Padding(
                                                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                                                        child: Text(
                                                          _youtubeSeekFeedbackText!,
                                                          style: const TextStyle(
                                                            color: Colors.white,
                                                            fontSize: 14,
                                                            fontWeight: FontWeight.w800,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            if (isLandscapeWatch)
                                              Positioned(
                                                right: 4,
                                                bottom: 44,
                                                child: Row(
                                                  mainAxisSize: MainAxisSize.min,
                                                  children: [
                                                    _videoOverlayButton(
                                                      icon: Icons.stay_current_portrait_rounded,
                                                      tooltip: 'Mode potret',
                                                      onTap: _toggleYoutubeLandscape,
                                                    ),
                                                    const SizedBox(width: 6),
                                                    ValueListenableBuilder<bool>(
                                                      valueListenable: _youtubeLandscapeDiscussionVisible,
                                                      builder: (context, visible, _) => _videoOverlayButton(
                                                        icon: visible
                                                            ? Icons.chat_rounded
                                                            : Icons.chat_bubble_outline_rounded,
                                                        tooltip: visible
                                                            ? 'Sembunyikan komentar'
                                                            : 'Tampilkan komentar',
                                                        onTap: () {
                                                          _youtubeLandscapeControlsVisible.value = true;
                                                          _showLandscapeControls();
                                                          _youtubeLandscapeDiscussionVisible.value = !visible;
                                                        },
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              )
                                            else
                                              Positioned(
                                                right: 4,
                                                bottom: 44,
                                                child: _videoOverlayButton(
                                                  icon: Icons.stay_current_landscape_rounded,
                                                  tooltip: 'Mode lanskap',
                                                  onTap: _toggleYoutubeLandscape,
                                                ),
                                              ),
                                          ],
                                        );
                                      },
                                    ),
                                  ),
                                if (isFloating && !systemPipActive)
                                  Positioned.fill(
                                    child: GestureDetector(
                                      behavior: HitTestBehavior.translucent,
                                      onTap: _showPipControls,
                                      onPanStart: (details) => _beginPipDrag(
                                        details,
                                        position ?? defaultPipPosition,
                                      ),
                                      onPanUpdate: (details) => _updatePipDrag(
                                        details,
                                        screenSize: size,
                                        pipWidth: pipWidth,
                                        pipHeight: pipHeight,
                                        minTop: pipMinTop,
                                        maxTop: pipMaxTop,
                                      ),
                                      onPanEnd: (details) => _endPipDrag(
                                        velocity: details.velocity,
                                        screenSize: size,
                                        pipWidth: pipWidth,
                                        pipHeight: pipHeight,
                                        minTop: pipMinTop,
                                        maxTop: pipMaxTop,
                                      ),
                                      onPanCancel: () => _endPipDrag(
                                        screenSize: size,
                                        pipWidth: pipWidth,
                                        pipHeight: pipHeight,
                                        minTop: pipMinTop,
                                        maxTop: pipMaxTop,
                                      ),
                                      child: Stack(
                                        fit: StackFit.expand,
                                        children: [
                                          // Bingkai PiP punya bayangan agar terpisah dari feed,
                                          // tanpa memindahkan atau membuat ulang AndroidView.
                                          Container(
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                color: Colors.white.withValues(alpha: 0.22),
                                                width: 1,
                                              ),
                                              borderRadius: BorderRadius.circular(14),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.black.withValues(alpha: 0.34),
                                                  blurRadius: 16,
                                                  offset: const Offset(0, 7),
                                                ),
                                              ],
                                            ),
                                          ),
                                          // Progress selalu tampak walau kontrol PiP disembunyikan.
                                          Positioned(
                                            left: 1,
                                            right: 1,
                                            bottom: 1,
                                            height: 3,
                                            child: ClipRRect(
                                              borderRadius: const BorderRadius.vertical(
                                                bottom: Radius.circular(13),
                                              ),
                                              child: ValueListenableBuilder<NativeYoutubeState>(
                                                valueListenable: _nativeStateNotifier,
                                                builder: (context, state, _) {
                                                  final durationMs = state.duration.inMilliseconds;
                                                  final progress = durationMs <= 0
                                                      ? 0.0
                                                      : (state.position.inMilliseconds / durationMs)
                                                          .clamp(0.0, 1.0)
                                                          .toDouble();
                                                  return LinearProgressIndicator(
                                                    value: progress,
                                                    minHeight: 3,
                                                    backgroundColor: Colors.white.withValues(alpha: 0.28),
                                                    valueColor: const AlwaysStoppedAnimation<Color>(
                                                      Color(0xFFFF0033),
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                          ),
                                          if (_pipControlsVisible) ...[
                                            Positioned(
                                              top: 5,
                                              right: 5,
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  _pipActionButton(
                                                    icon: Icons.open_in_full_rounded,
                                                    tooltip: 'Perbesar',
                                                    onTap: _openYoutubeWatchFromPlayer,
                                                  ),
                                                  const SizedBox(width: 4),
                                                  _pipActionButton(
                                                    icon: Icons.close_rounded,
                                                    tooltip: 'Tutup',
                                                    onTap: () async {
                                                      try {
                                                        await _youtubeController.pauseVideo();
                                                      } catch (_) {}
                                                      if (!mounted) return;
                                                      _updateHomeState(() {
                                                        _youtubePipMode = false;
                                                        _pipControlsVisible = false;
                                                      });
                                                    },
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Center(
                                              child: ValueListenableBuilder<NativeYoutubeState>(
                                                valueListenable: _nativeStateNotifier,
                                                builder: (context, nativeState, _) {
                                                  final playing = nativeState.isEffectivelyPlaying;
                                                  return Row(
                                                    mainAxisSize: MainAxisSize.min,
                                                    children: [
                                                      _pipControlButton(
                                                        icon: Icons.skip_previous_rounded,
                                                        size: 34,
                                                        tooltip: 'Sebelumnya',
                                                        onTap: () {
                                                          _showPipControls();
                                                          unawaited(_previous());
                                                        },
                                                      ),
                                                      const SizedBox(width: 6),
                                                      _pipControlButton(
                                                        icon: playing
                                                            ? Icons.pause_rounded
                                                            : Icons.play_arrow_rounded,
                                                        size: 42,
                                                        tooltip: playing ? 'Jeda' : 'Putar',
                                                        onTap: () {
                                                          _showPipControls();
                                                          unawaited(_togglePlayPause());
                                                        },
                                                      ),
                                                      const SizedBox(width: 6),
                                                      _pipControlButton(
                                                        icon: Icons.skip_next_rounded,
                                                        size: 34,
                                                        tooltip: 'Berikutnya',
                                                        onTap: () {
                                                          _showPipControls();
                                                          unawaited(_next());
                                                        },
                                                      ),
                                                    ],
                                                  );
                                                },
                                              ),
                                            ),
                                            Positioned(
                                              left: 8,
                                              right: 8,
                                              bottom: 7,
                                              child: IgnorePointer(
                                                child: Align(
                                                  alignment: Alignment.bottomCenter,
                                                  child: Container(
                                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                                                    decoration: BoxDecoration(
                                                      color: Colors.black.withValues(alpha: 0.60),
                                                      borderRadius: BorderRadius.circular(8),
                                                    ),
                                                    child: Text(
                                                      _currentVideo?.title ?? appName,
                                                      maxLines: 1,
                                                      overflow: TextOverflow.ellipsis,
                                                      style: const TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 10.5,
                                                        fontWeight: FontWeight.w700,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ],
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      ),
                    );
                        },
                      );
                    },
                  );
                },
              ),


            if (watch != null && !systemPipActive)
              Positioned(
                left: 0,
                right: 0,
                top: isLandscapeWatch ? 0 : topInset + playerHeight,
                bottom: isLandscapeWatch ? 0 : null,
                height: isLandscapeWatch
                    ? null
                    : max(0.0, size.height - (topInset + playerHeight)),
                // Ikut swipe lewat Transform (hanya repaint, tanpa layout ulang),
                // dan halaman tidak ikut rebuild tiap frame drag.
                child: ValueListenableBuilder<double>(
                  valueListenable: _youtubeSwipeDyNotifier,
                  builder: (context, swipeDy, page) => TweenAnimationBuilder<double>(
                    tween: Tween<double>(end: isLandscapeWatch ? 0.0 : swipeDy),
                    duration: _youtubePortraitSwipeDragging
                        ? Duration.zero
                        : const Duration(milliseconds: 220),
                    curve: Curves.easeOutCubic,
                    child: page,
                    builder: (context, dy, child) => Opacity(
                      opacity: isLandscapeWatch
                          ? 1.0
                          : (1.0 - (dy / 420.0).clamp(0.0, 0.14)).toDouble(),
                      child: Transform.translate(
                        offset: Offset(0, dy),
                        child: Transform.scale(
                          alignment: Alignment.topCenter,
                          scale: isLandscapeWatch
                              ? 1.0
                              : (1.0 - (dy / 1600.0).clamp(0.0, 0.05)).toDouble(),
                          child: child,
                        ),
                      ),
                    ),
                  ),
                  child: YoutubeWatchPage(
                      key: ValueKey<String>('watch-${watch.videoId}'),
                      video: watch,
                  onBack: _closeYoutubeWatch,
                  onPip: _enterFloatingPip,
                  onPlay: _openYoutubeVideo,
                  signedIn: YoutubeAccountService.instance.isSignedIn,
                  subscribed: false,
                  onRate: _rateYoutubeVideo,
                  onOpenChannel: _openChannelPage,
                  onToggleLandscape: _toggleYoutubeLandscape,
                  onSetQuality: _setYoutubeQuality,
                  quality: _youtubeQuality,
                  captionsEnabled: _youtubeCaptionsEnabled,
                  captionLanguage: _youtubeCaptionLanguage,
                  onSetCaptions: _setYoutubeCaptions,
                  onSetCaptionLanguage: _setYoutubeCaptionLanguage,
                  onToggleRepeat: _toggleYoutubeRepeatCurrent,
                  repeatCurrent: _youtubeRepeatCurrent,
                  onToggleShuffle: _toggleShuffle,
                  onToggleSmartShuffle: _toggleSmartShuffle,
                  onCycleLoopMode: _cycleLoopMode,
                  shuffleEnabled: _playerUiState.value.isShuffle,
                  smartShuffleEnabled: _playerUiState.value.isSmartShuffle,
                  loopMode: _playerUiState.value.loopMode,
                  landscapeDiscussionVisible: _youtubeLandscapeDiscussionVisible,
                  nativeState: _nativeStateNotifier,
                  playerUiState: _playerUiState,
                  onSeekFromLyrics: (position) async {
                    await _youtubeController.seekTo(
                      seconds: position.inMilliseconds / 1000.0,
                    );
                  },
                  onSubscribe: (channelId) async {
                    try {
                      await YoutubeAccountService.instance.subscribe(channelId);
                      if (mounted) _toast('Channel di-subscribe.');
                    } catch (e) {
                      if (mounted) _toast('Gagal subscribe: $e');
                    }
                  },
                    ),
                ),
              ),        ],
        ),
      );
    }
}
