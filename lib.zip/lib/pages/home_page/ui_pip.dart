part of '../home_page.dart';

extension _HomeYoutubePipUi on _HomePageState {
    void _beginPipDrag(DragStartDetails details, Offset currentPosition) {
      _youtubePipDragStartGlobal = details.globalPosition;
      _youtubePipDragStartOffset = currentPosition;
    }

    void _updatePipDrag(
      DragUpdateDetails details, {
      required Size screenSize,
      required double pipWidth,
      required double pipHeight,
      required double minTop,
      required double maxTop,
    }) {
      final startGlobal = _youtubePipDragStartGlobal;
      final startOffset = _youtubePipDragStartOffset;
      if (startGlobal == null || startOffset == null) return;

      final delta = details.globalPosition - startGlobal;
      final maxLeft = max(8.0, screenSize.width - pipWidth - 8.0);
      final safeMaxTop = max(minTop, maxTop);
      final next = Offset(
        (startOffset.dx + delta.dx).clamp(8.0, maxLeft).toDouble(),
        (startOffset.dy + delta.dy).clamp(minTop, safeMaxTop).toDouble(),
      );
      _youtubePipPosition.value = next;
    }

    void _endPipDrag({Velocity? velocity, Size? screenSize, double? pipWidth, double? pipHeight, double? minTop, double? maxTop}) {
      final size = screenSize;
      final width = pipWidth;
      final height = pipHeight;
      final current = _youtubePipPosition.value;
      if (size != null && width != null && height != null && minTop != null && maxTop != null && current != null) {
        final maxLeft = max(8.0, size.width - width - 8.0);
        final safeMaxTop = max(minTop, maxTop);
        final vx = velocity?.pixelsPerSecond.dx ?? 0.0;
        final vy = velocity?.pixelsPerSecond.dy ?? 0.0;
        final projected = Offset(
          current.dx + vx * 0.16,
          current.dy + vy * 0.16,
        );
        final targetLeft = projected.dx + width / 2 < size.width / 2 ? 8.0 : maxLeft;
        final targetTop = projected.dy + height / 2 < size.height / 2
            ? minTop
            : safeMaxTop;
        _youtubePipPosition.value = Offset(targetLeft, targetTop);
      }
      _youtubePipDragStartGlobal = null;
      _youtubePipDragStartOffset = null;
    }
    void _showPipControls() {
      _pipControlsTimer?.cancel();
      _updateHomeState(() => _pipControlsVisible = true);
      _pipControlsTimer = Timer(const Duration(seconds: 3), () {
        if (mounted) _updateHomeState(() => _pipControlsVisible = false);
      });
    }
    Widget _pipControlButton({
      required IconData icon,
      required double size,
      required String tooltip,
      required VoidCallback onTap,
    }) {
      return Material(
        color: Colors.black.withValues(alpha: 0.55),
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Tooltip(
            message: tooltip,
            child: SizedBox(
              width: size,
              height: size,
              child: Icon(icon, color: Colors.white, size: size * 0.66),
            ),
          ),
        ),
      );
    }
    Widget _pipActionButton({
      required IconData icon,
      required String tooltip,
      required VoidCallback onTap,
    }) {
      return Material(
        color: Colors.black.withValues(alpha: 0.62),
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Tooltip(
            message: tooltip,
            child: SizedBox(
              width: 30,
              height: 30,
              child: Icon(icon, color: Colors.white, size: 16),
            ),
          ),
        ),
      );
    }
}
