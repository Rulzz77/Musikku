import '../models/youtube_search_result.dart';
import 'youtube_music_metadata_parser.dart';

/// Stateless decoding of YouTube API payloads into app models.
class YoutubeSearchResponseParser {
  static List<YoutubeSearchResult> resultsFromJson(Object? raw) {
    if (raw is! List) {
      return <YoutubeSearchResult>[];
    }

    final list = raw
        .whereType<Map>()
        .map((item) => YoutubeSearchResult.fromJson(
              Map<String, dynamic>.from(item),
            ))
        .where((video) => video.videoId.isNotEmpty)
        .toList();

    // channelId bisa kosong pada sebagian hasil youtube_explode. Jangan buang
    // seluruh daftar lagu hanya karena satu item tidak membawa metadata channel;
    // playback dan metadata judul tetap valid tanpa channelId.
    return list;
  }

  static List<YoutubeSearchResult> parseVideoResources(List items) {
    final out = <YoutubeSearchResult>[];
    for (final item in items) {
      if (item is! Map) continue;
      final video = YoutubeSearchResult.fromVideoResource(
        Map<String, dynamic>.from(item),
        pickThumbnail: pickThumbnail,
        decode: decodeHtml,
      );
      if (video == null) continue;
      final seconds = video.durationSeconds;
      if (!video.isLive && !video.isUpcoming && seconds != null && seconds <= 30) {
        continue;
      }
      final releaseMetadata = YoutubeMusicMetadataParser.parse(
        title: video.title,
        description: video.description,
      );
      out.add(video.copyWith(
        artistName: releaseMetadata.artistName,
        album: releaseMetadata.album,
      ));
    }
    return out;
  }

  static List<YoutubeSearchResult> parseSearchItems(List items) {
    final results = <YoutubeSearchResult>[];

    for (final item in items) {
      if (item is! Map) {
        continue;
      }

      final id = item['id'];
      final snippet = item['snippet'];

      if (id is! Map || snippet is! Map) {
        continue;
      }

      final videoId = id['videoId']?.toString() ?? '';

      if (videoId.isEmpty) {
        continue;
      }

      final title = decodeHtml(snippet['title']?.toString() ?? 'Tanpa judul');
      final description = decodeHtml(snippet['description']?.toString() ?? '');
      final channelTitle = decodeHtml(
        snippet['channelTitle']?.toString() ?? 'Unknown',
      );
      final releaseMetadata = YoutubeMusicMetadataParser.parse(
        title: title,
        description: description,
      );
      results.add(
        YoutubeSearchResult(
          videoId: videoId,
          title: title,
          description: description,
          channelTitle: channelTitle,
          artistName: releaseMetadata.artistName,
          album: releaseMetadata.album,
          thumbnailUrl: pickThumbnail(snippet['thumbnails']),
          publishedAt: DateTime.tryParse(snippet['publishedAt']?.toString() ?? ''),
          channelId: snippet['channelId']?.toString() ?? '',
        ),
      );
    }

    return results;
  }

  static String pickThumbnail(dynamic thumbnails) {
    if (thumbnails is! Map) {
      return '';
    }

    for (final size in const ['maxres', 'high', 'standard', 'medium', 'default']) {
      final image = thumbnails[size];

      if (image is Map) {
        final url = image['url']?.toString() ?? '';

        if (url.isNotEmpty) {
          return url;
        }
      }
    }

    return '';
  }

  static String decodeHtml(String input) {
    var text = input.replaceAllMapped(
      RegExp(r'&#(\d+);'),
      (match) {
        final code = int.tryParse(match.group(1)!);

        if (code == null || code > 0x10FFFF) {
          return match.group(0)!;
        }

        return String.fromCharCode(code);
      },
    );

    text = text.replaceAllMapped(
      RegExp(r'&#x([0-9a-fA-F]+);'),
      (match) {
        final code = int.tryParse(match.group(1)!, radix: 16);

        if (code == null || code > 0x10FFFF) {
          return match.group(0)!;
        }

        return String.fromCharCode(code);
      },
    );

    return text
        .replaceAll('&quot;', '"')
        .replaceAll('&apos;', "'")
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&amp;', '&');
  }
}
