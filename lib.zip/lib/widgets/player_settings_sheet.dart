import 'dart:async';

import 'package:flutter/material.dart';

/// Pilihan kualitas video. Nilai dikirim ke player native sebagai preferensi.
/// YouTube tetap menentukan kualitas aktual secara adaptif.
const List<({String value, String label})> youtubeQualityOptions = [
  (value: 'default', label: 'Otomatis (YouTube)'),
  (value: 'tiny', label: '144p (paling hemat data)'),
  (value: 'small', label: '240p'),
  (value: 'medium', label: '360p'),
  (value: 'large', label: '480p'),
  (value: 'hd720', label: '720p HD'),
  (value: 'hd1080', label: '1080p Full HD'),
];

/// Mode subtitle dibuat eksplisit agar "track langsung" dan "terjemahan
/// otomatis" tidak tercampur seperti versi sebelumnya.
const List<({String value, String label, String description})> youtubeCaptionOptions = [
  (
    value: 'id',
    label: 'Indonesia',
    description: 'Pakai track Indonesia langsung bila tersedia.',
  ),
  (
    value: 'en',
    label: 'Inggris',
    description: 'Pakai track Inggris langsung bila tersedia.',
  ),
  (
    value: 'original',
    label: 'Bahasa asli',
    description: 'Pakai track asli pertama yang tersedia.',
  ),
  (
    value: 'auto:id',
    label: 'Terjemahan otomatis Indonesia',
    description: 'Terjemahkan track yang tersedia ke Indonesia.',
  ),
  (
    value: 'auto:en',
    label: 'Terjemahan otomatis Inggris',
    description: 'Terjemahkan track yang tersedia ke Inggris.',
  ),
];

String youtubeQualityLabel(String value) {
  for (final option in youtubeQualityOptions) {
    if (option.value == value) return option.label;
  }
  return value;
}

String youtubeCaptionLabel(String value) {
  for (final option in youtubeCaptionOptions) {
    if (option.value == value) return option.label;
  }
  return value;
}

/// Sheet pengaturan pemutar.
Future<void> showYoutubePlayerSettingsSheet({
  required BuildContext context,
  required bool repeat,
  required String quality,
  required bool captionsEnabled,
  required String captionLanguage,
  required VoidCallback onToggleRepeat,
  required Future<void> Function(String quality) onSetQuality,
  required Future<void> Function(bool enabled) onSetCaptions,
  required Future<void> Function(String language) onSetCaptionLanguage,
}) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    useSafeArea: true,
    isScrollControlled: true,
    constraints: const BoxConstraints(maxWidth: 560),
    builder: (sheetContext) {
      var repeatValue = repeat;
      var qualityValue = quality;
      var qualityOpen = false;
      var qualityApplying = false;
      var captionsValue = captionsEnabled;
      var captionLanguageValue = captionLanguage;

      return StatefulBuilder(
        builder: (context, setSheetState) {
          final scheme = Theme.of(context).colorScheme;

          Future<void> chooseQuality(String value) async {
            if (qualityApplying) return;
            setSheetState(() {
              qualityValue = value;
              qualityOpen = false;
              qualityApplying = true;
            });
            try {
              await onSetQuality(value);
            } finally {
              if (sheetContext.mounted) {
                setSheetState(() => qualityApplying = false);
              }
            }
          }

          Future<void> chooseCaption(String value) async {
            setSheetState(() => captionLanguageValue = value);
            try {
              await onSetCaptionLanguage(value);
            } catch (_) {
              // Error sudah ditampilkan pemanggil.
            }
          }

          return SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Pengaturan video',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 12),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  secondary: Icon(
                    Icons.repeat_rounded,
                    color: repeatValue ? scheme.primary : null,
                  ),
                  title: const Text('Ulangi video'),
                  value: repeatValue,
                  onChanged: (_) {
                    onToggleRepeat();
                    setSheetState(() => repeatValue = !repeatValue);
                  },
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  secondary: Icon(
                    Icons.translate_rounded,
                    color: captionsValue ? scheme.primary : null,
                  ),
                  title: const Text('Subtitle'),
                  subtitle: Text(
                    captionsValue
                        ? 'Aktif • ${youtubeCaptionLabel(captionLanguageValue)}'
                        : 'Mati • ${youtubeCaptionLabel(captionLanguageValue)}',
                  ),
                  value: captionsValue,
                  onChanged: (value) {
                    setSheetState(() => captionsValue = value);
                    unawaited(onSetCaptions(value));
                  },
                ),
                const SizedBox(height: 4),
                const Text(
                  'Bahasa subtitle',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  initialValue: youtubeCaptionOptions.any((o) => o.value == captionLanguageValue)
                      ? captionLanguageValue
                      : youtubeCaptionOptions.first.value,
                  isExpanded: true,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: scheme.surfaceContainerHighest,
                    prefixIcon: const Icon(Icons.translate_rounded),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide.none,
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  ),
                  borderRadius: BorderRadius.circular(14),
                  menuMaxHeight: 320,
                  items: [
                    for (final option in youtubeCaptionOptions)
                      DropdownMenuItem<String>(
                        value: option.value,
                        child: Text(
                          option.label,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ),
                  ],
                  onChanged: (value) {
                    if (value != null) unawaited(chooseCaption(value));
                  },
                ),
                const SizedBox(height: 6),
                Text(
                  youtubeCaptionOptions
                          .where((option) => option.value == captionLanguageValue)
                          .map((option) => option.description)
                          .firstOrNull ??
                      '',
                  style: TextStyle(
                    color: scheme.onSurfaceVariant,
                    fontSize: 11.5,
                    height: 1.3,
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    const Icon(Icons.high_quality_rounded),
                    const SizedBox(width: 16),
                    const Expanded(
                      child: Text('Kualitas', style: TextStyle(fontSize: 16)),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Text(
                    'Resolusi YouTube dipilih otomatis berdasarkan koneksi, perangkat, dan kondisi playback. Penguncian 144p/240p/360p/480p/720p/1080p tidak tersedia lewat IFrame Player API.',
                    style: TextStyle(
                      color: scheme.onSurfaceVariant,
                      fontSize: 12,
                      height: 1.35,
                    ),
                  ),
                ),
                Material(
                  color: scheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(14),
                  clipBehavior: Clip.antiAlias,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      InkWell(
                        onTap: () => setSheetState(() => qualityOpen = !qualityOpen),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 14,
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.hd_rounded),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  youtubeQualityLabel(qualityValue),
                                  style: const TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                              if (qualityApplying)
                                const Padding(
                                  padding: EdgeInsets.only(right: 8),
                                  child: SizedBox(
                                    width: 16,
                                    height: 16,
                                    child: CircularProgressIndicator(strokeWidth: 2),
                                  ),
                                ),
                              AnimatedRotation(
                                turns: qualityOpen ? 0.5 : 0,
                                duration: const Duration(milliseconds: 180),
                                child: const Icon(
                                  Icons.arrow_drop_down_rounded,
                                  size: 28,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      AnimatedSize(
                        duration: const Duration(milliseconds: 180),
                        curve: Curves.easeOut,
                        alignment: Alignment.topCenter,
                        child: qualityOpen
                            ? Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Divider(height: 1, color: scheme.outlineVariant),
                                  for (final option in youtubeQualityOptions)
                                    InkWell(
                                      onTap: () => unawaited(
                                        chooseQuality(option.value),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 14,
                                          vertical: 12,
                                        ),
                                        child: Row(
                                          children: [
                                            SizedBox(
                                              width: 24,
                                              child: option.value == qualityValue
                                                  ? Icon(
                                                      Icons.check_rounded,
                                                      size: 20,
                                                      color: scheme.primary,
                                                    )
                                                  : null,
                                            ),
                                            const SizedBox(width: 12),
                                            Expanded(
                                              child: Text(
                                                option.label,
                                                style: TextStyle(
                                                  fontSize: 15,
                                                  fontWeight: option.value == qualityValue
                                                      ? FontWeight.w800
                                                      : FontWeight.w500,
                                                  color: option.value == qualityValue
                                                      ? scheme.primary
                                                      : null,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                ],
                              )
                            : const SizedBox(width: double.infinity),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Kualitas: preferensi/hint. YouTube tetap memilih kualitas aktual secara adaptif; nilai aktual dapat dilihat di Diagnostik Player.',
                  style: TextStyle(
                    color: scheme.onSurfaceVariant,
                    fontSize: 12,
                    height: 1.3,
                  ),
                ),
              ],
            ),
          );
        },
      );
    },
  );
}
