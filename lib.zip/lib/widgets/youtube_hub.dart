import 'dart:async';
import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart' show ValueListenable;
import 'package:flutter/material.dart';

import '../app_info.dart';
import '../models/listening_stat.dart';
import '../models/native_youtube_state.dart';
import '../models/playlist.dart';
import '../models/youtube_search_result.dart';
import '../pages/app_settings_page.dart';
import '../pages/album_detail_page.dart';
import '../pages/artist_page.dart';
import '../pages/local_music_page.dart';
import '../pages/music_studio_page.dart';
import '../pages/stats_page.dart';
import '../pages/youtube_channel_page.dart';
import '../pages/youtube_search_page.dart';
import '../services/app_settings.dart';
import '../services/music_title_formatter.dart';
import '../services/search_suggest_service.dart';
import '../services/smart_playlist_service.dart';
import '../services/storage_service.dart';
import '../services/youtube_search_service.dart';
import 'app_update_sheet.dart';
import 'album_artwork_image.dart';
import 'channel_avatar.dart';
import 'live_badge.dart';
import 'unified_artwork.dart';
import 'playlist_artwork.dart';
import 'flow_components.dart';
import 'music_design.dart';

part 'youtube_hub/startup_actions.dart';
part 'youtube_hub/home_views.dart';
part 'youtube_hub/search_views.dart';
part 'youtube_hub/video_components.dart';
part 'youtube_hub/library_views.dart';

/// Jembatan dari HomePage ke hub: tombol Back sistem dan membuka channel dari
/// halaman tonton. Halaman channel hidup di dalam hub, jadi video / PiP yang
/// tampil di atas hub tidak menutup halaman channel.
class YoutubeHubController {
  bool Function()? _onBack;
  void Function(String channelId, String title, String thumbnailUrl)? _onOpenChannel;
  ValueChanged<int>? _onSelectTab;

  /// Select one of the persistent hub destinations from an overlay page.
  void selectTab(int index) => _onSelectTab?.call(index);

  /// true kalau Back dipakai untuk menutup halaman channel di hub.
  bool handleBack() => _onBack?.call() ?? false;

  void openChannel(String channelId, {String title = '', String thumbnailUrl = ''}) {
    _onOpenChannel?.call(channelId, title, thumbnailUrl);
  }
}

class _OpenChannel {
  final String id;
  final String title;
  final String thumbnailUrl;
  const _OpenChannel(this.id, this.title, this.thumbnailUrl);
}

class YoutubeHub extends StatefulWidget {
  final YoutubeHubController? controller;
  final Future<void> Function(YoutubeSearchResult) onPlay;
  final VoidCallback onClose;

  /// Tinggi mini player yang tampil di atas bar navigasi hub (0 jika tidak ada).
  /// Dipakai agar daftar video tidak tertutup mini player.
  final double bottomInset;
  final Map<String, double> watchProgress;
  final Map<String, double> watchDuration;
  final List<YoutubeSearchResult> recentlyPlayed;
  final List<YoutubeSearchResult> favorites;
  final List<ListeningStat> listeningStats;
  final int customPlaylistCount;
  final VoidCallback? onOpenCustomPlaylists;
  final ValueChanged<Playlist>? onOpenCustomPlaylist;
  /// Playlist buatan pengguna, ditampilkan di beranda.
  final List<Playlist> customPlaylists;
  final VoidCallback? onCustomPlaylistsChanged;
  final String? currentVideoId;
  final YoutubeSearchResult? currentVideo;
  final Future<void> Function()? onPlayPause;
  final Future<void> Function()? onNext;
  final Future<void> Function()? onPrevious;
  final bool isPlaying;
  final ValueListenable<NativeYoutubeState>? nativeState;
  final Future<void> Function(YoutubeSearchResult video)? onStartRadio;
  final Future<void> Function(YoutubeSearchResult video, List<YoutubeSearchResult> list) onPlayFromList;
  final ValueChanged<YoutubeSearchResult> onAddToQueue;
  final ValueChanged<YoutubeSearchResult>? onShowVideoMenu;
  final ValueChanged<String>? onSearchQueryChanged;
  final VoidCallback? onOpenListeningRoom;
  final VoidCallback? onOpenCurrentLyrics;
  final VoidCallback? onOpenAudioSettings;
  final AppSettingsController settings;

  const YoutubeHub({
    super.key,
    this.controller,
    required this.onPlay,
    required this.onClose,
    this.bottomInset = 0,
    this.watchProgress = const {},
    this.watchDuration = const {},
    this.recentlyPlayed = const [],
    this.favorites = const [],
    this.listeningStats = const [],
    this.customPlaylistCount = 0,
    this.onOpenCustomPlaylists,
    this.onOpenCustomPlaylist,
    this.customPlaylists = const [],
    this.onCustomPlaylistsChanged,
    this.currentVideoId,
    this.currentVideo,
    this.onPlayPause,
    this.onNext,
    this.onPrevious,
    this.isPlaying = false,
    this.nativeState,
    this.onStartRadio,
    required this.onPlayFromList,
    required this.onAddToQueue,
    this.onShowVideoMenu,
    this.onSearchQueryChanged,
    this.onOpenListeningRoom,
    this.onOpenCurrentLyrics,
    this.onOpenAudioSettings,
    required this.settings,
  });

  @override
  State<YoutubeHub> createState() => _YoutubeHubState();
}

enum _YoutubeSection { home, explore, samples, library }
enum _SearchResultsTab { all, songs, artists, albums, videos }

class _YoutubeHubState extends State<YoutubeHub> {
  // ---------------------------------------------------------------------------
  // Services & controllers
  // ---------------------------------------------------------------------------

  final _searchController = TextEditingController();
  final _searchService = YoutubeSearchService();
  final _suggestService = SearchSuggestService();
  final _storage = StorageService();
  final Random _feedRandom = Random();

  // ---------------------------------------------------------------------------
  // Request bookkeeping (menolak hasil request lama)
  // ---------------------------------------------------------------------------

  int _homeRequestSequence = 0;
  int _chipRequestSequence = 0;
  int _exploreRequestSequence = 0;
  int _searchRequestId = 0;

  // ---------------------------------------------------------------------------
  // Navigasi & pencarian
  // ---------------------------------------------------------------------------

  _YoutubeSection _section = _YoutubeSection.home;
  bool _loading = false;
  String _error = '';
  String _query = '';
  YoutubeSearchFilters _activeSearchFilters = const YoutubeSearchFilters();
  List<String> _searchHistory = const [];
  List<YoutubeSearchResult> _searchResults = const [];
  List<YoutubeChannelSearchResult> _searchChannels = const [];
  bool _channelSearchLoading = false;
  bool _artistChannelMode = false;
  _SearchResultsTab _searchResultsTab = _SearchResultsTab.all;

  /// true selama tarik-untuk-refresh: RefreshIndicator sudah punya spinner
  /// sendiri, jadi spinner inline disembunyikan supaya tidak muncul dobel.
  bool _pullRefreshing = false;
  bool get _inlineLoading => _loading && !_pullRefreshing;

  // ---------------------------------------------------------------------------
  // Beranda
  // ---------------------------------------------------------------------------

  /// Chip filter aktif di beranda (0 = Semua). -1 = pencarian bebas.
  int _activeChip = 0;

  /// Isi chip Musik / Terpopuler / Video terbaru (kunci = indeks chip).
  final Map<int, List<YoutubeSearchResult>> _chipFeeds = {};
  bool _chipLoading = false;

  /// Video trending musik untuk beranda; tidak memerlukan akun.
  List<YoutubeSearchResult> _trending = const [];
  bool _feedLoading = false;
  String _feedError = '';

  List<YoutubeSearchResult> get _homeVideos => List<YoutubeSearchResult>.from(_trending);

  static const _chipTitles = <int, String>{
    1: 'Lagu populer',
    2: 'Lagu terbaru',
  };

  // ---------------------------------------------------------------------------
  // Jelajahi
  // ---------------------------------------------------------------------------

  /// Explore uses the shared cached search service so genre results are live,
  /// rather than hard-coded sample tracks.
  String _exploreCategory = 'Pop Indonesia';
  List<YoutubeSearchResult> _exploreResults = const [];
  bool _exploreLoading = false;
  String _exploreError = '';

  // One-at-a-time mood station lookup keeps the Radio page responsive and
  // prevents several rapid taps from starting overlapping searches.
  bool _radioMoodLoading = false;
  String _radioMoodLoadingName = '';

  static const List<String> _exploreCategories = [
    'Sedang tren',
    'Pop Indonesia',
    'Dangdut',
    'Dangdut/Koplo',
    'K-Pop',
    'Hip-hop',
    'Rock',
    'Jazz',
    'Lo-fi',
    'Musik religi',
    'Soundtrack',
    'Chill',
    'Sad',
    'Happy',
    'Energetic',
    'Focus',
    'Relax',
  ];

  static const Map<String, String> _exploreQueries = {
    // Jangan mewajibkan kata "official": banyak rilisan asli artis/label
    // independen tidak memakai marker itu pada judul atau metadata YouTube.
    'Pop Indonesia': 'lagu pop Indonesia',
    'Dangdut': 'lagu dangdut Indonesia',
    'Dangdut/Koplo': 'lagu dangdut koplo Indonesia',
    'K-Pop': 'K-pop songs latest',
    'Hip-hop': 'hip hop music',
    'Rock': 'rock music songs',
    'Jazz': 'jazz music songs',
    'Lo-fi': 'lofi hip hop music mix',
    'Musik religi': 'lagu religi Indonesia',
    'Soundtrack': 'soundtrack film Indonesia',
    'Chill': 'lagu chill Indonesia santai',
    'Sad': 'lagu galau Indonesia sedih',
    'Happy': 'lagu ceria Indonesia happy',
    'Energetic': 'lagu semangat Indonesia upbeat',
    'Focus': 'instrumental focus music',
    'Relax': 'lagu santai Indonesia akustik',
  };

  // ---------------------------------------------------------------------------
  // Halaman channel
  // ---------------------------------------------------------------------------

  /// Channel yang sedang dibuka (lapisan di atas hub). Null = tidak ada.
  _OpenChannel? _openedChannel;

  // ---------------------------------------------------------------------------
  // Lifecycle & controller
  // ---------------------------------------------------------------------------

  @override
  void initState() {
    super.initState();
    widget.controller?._onBack = _handleControllerBack;
    widget.controller?._onOpenChannel = _handleControllerOpenChannel;
    widget.controller?._onSelectTab = _selectDockDestination;
    unawaited(_restore());
  }

  @override
  void dispose() {
    if (widget.controller?._onBack == _handleControllerBack) {
      widget.controller?._onBack = null;
      widget.controller?._onOpenChannel = null;
      widget.controller?._onSelectTab = null;
    }
    _searchController.dispose();
    super.dispose();
  }

  bool _handleControllerBack() {
    if (_openedChannel != null) {
      setState(() => _openedChannel = null);
      return true;
    }
    if (_section != _YoutubeSection.home) {
      _searchRequestId++;
      _searchController.clear();
      setState(() {
        _section = _YoutubeSection.home;
        _query = '';
        _searchResults = const [];
        _searchChannels = const [];
        _artistChannelMode = false;
        _channelSearchLoading = false;
        _error = '';
        _loading = false;
      });
      return true;
    }
    return false;
  }

  void _handleControllerOpenChannel(String id, String title, String thumbnailUrl) {
    if (!mounted || id.isEmpty) return;
    setState(() => _openedChannel = _OpenChannel(id, title, thumbnailUrl));
  }

  // ---------------------------------------------------------------------------
  // Navigasi dock & refresh
  // ---------------------------------------------------------------------------

  void _selectDockDestination(int index) {
    final nextSection = _YoutubeSection.values[index];
    _searchRequestId++;
    _searchController.clear();
    setState(() {
      _section = nextSection;
      _query = '';
      _searchResults = const [];
      _searchChannels = const [];
      _artistChannelMode = false;
      _channelSearchLoading = false;
      _loading = false;
      _error = '';
      if (nextSection == _YoutubeSection.home) {
        _activeChip = 0;
      }
    });
    if (nextSection == _YoutubeSection.home) {
      unawaited(_loadHome());
    } else if (nextSection == _YoutubeSection.samples && _trending.isEmpty && !_feedLoading) {
      unawaited(_loadHome());
    } else if (nextSection == _YoutubeSection.explore) {
      unawaited(_loadExploreCategory(_exploreCategory));
    }
  }

  Future<void> _hubRefresh() async {
    _pullRefreshing = true;
    try {
      switch (_section) {
        case _YoutubeSection.home:
          if (_query.isNotEmpty) {
            await _search(keepResults: true);
          } else if (_activeChip >= 1 && _activeChip <= 3) {
            await _selectChip(_activeChip, force: true);
          } else {
            await _loadHome(force: true);
          }
        case _YoutubeSection.samples:
          await _loadHome(force: true);
        case _YoutubeSection.explore:
          await _loadExploreCategory(_exploreCategory, force: true);
        case _YoutubeSection.library:
          break;
      }
    } finally {
      _pullRefreshing = false;
      if (mounted) setState(() {});
    }
  }

  // ---------------------------------------------------------------------------
  // Build
  // ---------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    final channel = _openedChannel;
    final screenWidth = MediaQuery.sizeOf(context).width;
    final isTablet = screenWidth >= 900;
    final dockInset = screenWidth >= 700
        ? ((screenWidth - 820) / 2).clamp(14.0, 180.0).toDouble()
        : 14.0;

    final reduceMotion = MediaQuery.of(context).disableAnimations;
    final content = Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 1200),
        child: AnimatedSwitcher(
          duration: reduceMotion ? Duration.zero : const Duration(milliseconds: 260),
          reverseDuration: reduceMotion ? Duration.zero : const Duration(milliseconds: 190),
          switchInCurve: Curves.easeOutCubic,
          switchOutCurve: Curves.easeInCubic,
          transitionBuilder: (child, animation) {
            final slide = Tween<Offset>(
              begin: const Offset(0, 0.025),
              end: Offset.zero,
            ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutCubic));
            return FadeTransition(
              opacity: animation,
              child: SlideTransition(position: slide, child: child),
            );
          },
          child: RefreshIndicator(
            key: ValueKey<String>(
              'hub-${_section.name}-${_query.isNotEmpty ? 'search' : 'browse'}',
            ),
            onRefresh: _hubRefresh,
            child: CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              slivers: _hubSlivers(),
            ),
          ),
        ),
      ),
    );

    if (isTablet) {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(width: 8),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: NavigationRail(
                selectedIndex: _section.index,
                onDestinationSelected: _selectDockDestination,
                labelType: NavigationRailLabelType.all,
                minWidth: 78,
                groupAlignment: -0.55,
                backgroundColor: Colors.transparent,
                selectedIconTheme: IconThemeData(color: Theme.of(context).colorScheme.primary, size: 23),
                unselectedIconTheme: IconThemeData(color: Theme.of(context).colorScheme.onSurfaceVariant, size: 22),
                selectedLabelTextStyle: TextStyle(color: Theme.of(context).colorScheme.primary, fontSize: 10, fontWeight: FontWeight.w800),
                unselectedLabelTextStyle: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 10, fontWeight: FontWeight.w600),
                destinations: const [
                  NavigationRailDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: Text('Beranda')),
                  NavigationRailDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore_rounded), label: Text('Jelajah')),
                  NavigationRailDestination(icon: Icon(Icons.radio_outlined), selectedIcon: Icon(Icons.radio_rounded), label: Text('Radio')),
                  NavigationRailDestination(icon: Icon(Icons.library_music_outlined), selectedIcon: Icon(Icons.library_music_rounded), label: Text('Koleksi')),
                ],
              ),
            ),
          ),
          VerticalDivider(width: 1, thickness: 1, color: Theme.of(context).colorScheme.outlineVariant.withValues(alpha: 0.5)),
          Expanded(
            child: Stack(
              children: [
                Positioned.fill(child: content),
                if (channel != null)
                  Positioned.fill(
                    child: YoutubeChannelPage(
                      key: ValueKey('channel-${channel.id}'),
                      channelId: channel.id,
                      title: channel.title,
                      thumbnailUrl: channel.thumbnailUrl,
                      onPlay: widget.onPlay,
                      onClose: () => setState(() => _openedChannel = null),
                    ),
                  ),
              ],
            ),
          ),
        ],
      );
    }

    return Stack(
      children: [
        Positioned.fill(child: content),
        Positioned(
          left: dockInset,
          right: dockInset,
          bottom: MediaQuery.paddingOf(context).bottom + 8,
          child: _EditorialFloatingDock(
            selectedIndex: _section.index,
            onSelect: _selectDockDestination,
          ),
        ),
        if (channel != null)
          Positioned.fill(
            child: YoutubeChannelPage(
              key: ValueKey('channel-${channel.id}'),
              channelId: channel.id,
              title: channel.title,
              thumbnailUrl: channel.thumbnailUrl,
              onPlay: widget.onPlay,
              onClose: () => setState(() => _openedChannel = null),
            ),
          ),
      ],
    );
  }

  /// Seluruh sliver untuk daftar utama hub.
  List<Widget> _hubSlivers() {
    final list = _query.isNotEmpty ? _searchResults : _homeVideos;
    final theme = Theme.of(context);

    return [
      if (_query.isNotEmpty || _section != _YoutubeSection.home)
        _topBar(
          title: switch (_section) {
            _YoutubeSection.home => appName,
            _YoutubeSection.samples => 'Radio',
            _YoutubeSection.explore => 'Jelajahi',
            _YoutubeSection.library => 'Koleksi',
          },
        ),
      if (_query.isNotEmpty)
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 4),
            child: Align(
              alignment: Alignment.centerLeft,
              child: InputChip(
                avatar: const Icon(Icons.search_rounded, size: 18),
                label: Text(_query, maxLines: 1, overflow: TextOverflow.ellipsis),
                onPressed: _openSearch,
                onDeleted: _clearSearch,
              ),
            ),
          ),
        ),
      // Di Beranda, chip dirender oleh _homeSections() (di bawah header
      // sambutan) supaya tidak menempel di bawah status bar.
      if (_query.isNotEmpty) _chipRow(),
      if (_error.isNotEmpty)
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 6, 14, 6),
            child: Text(
              _error,
              style: TextStyle(color: theme.colorScheme.error, fontSize: 12),
            ),
          ),
        ),
      ..._hubBodySlivers(),
      if (_inlineLoading && list.isNotEmpty)
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Center(child: CircularProgressIndicator()),
          ),
        ),
      SliverToBoxAdapter(
        child: SizedBox(
          // Phones reserve space for the floating dock; tablets use a sidebar.
          height: 14 + (MediaQuery.sizeOf(context).width >= 900 ? 10 : 72) +
              widget.bottomInset + MediaQuery.paddingOf(context).bottom,
        ),
      ),
    ];
  }

  List<Widget> _hubBodySlivers() {
    switch (_section) {
      case _YoutubeSection.home:
        return _query.isEmpty ? _homeSections() : _hubSearchSlivers();
      case _YoutubeSection.samples:
        return _samplesView();
      case _YoutubeSection.explore:
        return _exploreView();
      case _YoutubeSection.library:
        return _libraryView();
    }
  }

  /// Hasil pencarian bersih dengan filter Semua, Lagu, Artis, Album, dan Video.
  /// Album hanya ditampilkan bila metadata album memang tersedia; tidak dibuat
  /// dari tebakan judul video.
  List<Widget> _hubSearchSlivers() {
    final songs = _searchResults
        .where(YoutubeSearchService.isMusicCandidate)
        .toList(growable: false);
    final albums = <String, List<YoutubeSearchResult>>{};
    for (final video in _searchResults) {
      final album = video.album.trim();
      if (album.isNotEmpty) albums.putIfAbsent(album, () => []).add(video);
    }

    final showArtists = _searchResultsTab == _SearchResultsTab.all ||
        _searchResultsTab == _SearchResultsTab.artists;
    final showSongs = _searchResultsTab == _SearchResultsTab.all ||
        _searchResultsTab == _SearchResultsTab.songs;
    final showVideos = _searchResultsTab == _SearchResultsTab.videos;
    final showAlbums = _searchResultsTab == _SearchResultsTab.albums;

    return [
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 1, 14, 8),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                for (final entry in <(_SearchResultsTab, String)>[
                  (_SearchResultsTab.all, 'Semua'),
                  (_SearchResultsTab.songs, 'Lagu'),
                  (_SearchResultsTab.artists, 'Artis'),
                  (_SearchResultsTab.albums, 'Album'),
                  (_SearchResultsTab.videos, 'Video'),
                ]) ...[
                  if (entry != (_SearchResultsTab.all, 'Semua')) const SizedBox(width: 7),
                  ChoiceChip(
                    label: Text(entry.$2),
                    selected: _searchResultsTab == entry.$1,
                    onSelected: (_) => setState(() => _searchResultsTab = entry.$1),
                    showCheckmark: false,
                    visualDensity: VisualDensity.compact,
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
      if (showArtists && _searchChannels.isNotEmpty) ...[
        _sectionHeader('Artis'),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 136,
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
              scrollDirection: Axis.horizontal,
              itemCount: _searchChannels.length,
              separatorBuilder: (_, _) => const SizedBox(width: 10),
              itemBuilder: (context, index) => _hubChannelCard(_searchChannels[index]),
            ),
          ),
        ),
      ],
      if (showArtists && _searchChannels.isEmpty && !_channelSearchLoading &&
          _searchResultsTab == _SearchResultsTab.artists)
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 20, 14, 20),
            child: Center(
              child: OutlinedButton.icon(
                onPressed: () => _searchChannelsForCurrentQuery(artistMode: true),
                icon: const Icon(Icons.person_search_rounded),
                label: const Text('Cari artis terkait'),
              ),
            ),
          ),
        ),
      if (showArtists && _channelSearchLoading && _searchChannels.isEmpty)
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.all(18),
            child: Center(child: CircularProgressIndicator()),
          ),
        ),
      if (showSongs || showVideos) ...[
        _sectionHeader(showVideos ? 'Video terkait' : 'Lagu'),
        if (_inlineLoading && _searchResults.isEmpty)
          const SliverToBoxAdapter(
            child: Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
          )
        else if ((showSongs ? songs : _searchResults).isEmpty)
          SliverToBoxAdapter(
            child: _searchEmptyState(showVideos ? 'Video belum ditemukan' : 'Lagu belum ditemukan'),
          )
        else
          SliverList.builder(
            itemCount: (showSongs ? songs : _searchResults).length,
            itemBuilder: (context, index) => _videoCard((showSongs ? songs : _searchResults)[index]),
          ),
      ],
      if (showAlbums) ...[
        _sectionHeader('Album'),
        if (albums.isEmpty)
          SliverToBoxAdapter(
            child: _searchEmptyState('Metadata album belum tersedia untuk hasil ini'),
          )
        else
          SliverList.builder(
            itemCount: albums.length,
            itemBuilder: (context, index) {
              final entry = albums.entries.elementAt(index);
              final first = entry.value.first;
              return ListTile(
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(9),
                  child: UnifiedArtwork(track: first, width: 48, height: 48, fit: BoxFit.cover),
                ),
                title: Text(entry.key, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text('${entry.value.length} lagu · ${first.artistName.isNotEmpty ? first.artistName : first.channelTitle}'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => _openAlbumDetail(entry.key, entry.value),
              );
            },
          ),
      ],
      if (_searchResultsTab == _SearchResultsTab.all &&
          _searchResults.isEmpty && _searchChannels.isEmpty && !_inlineLoading)
        SliverToBoxAdapter(child: _searchEmptyState('Tidak ada hasil yang cocok')),
      if (_searchResultsTab == _SearchResultsTab.artists &&
          _searchChannels.isEmpty && !_channelSearchLoading)
        const SliverToBoxAdapter(child: SizedBox(height: 1)),
    ];
  }

  Widget _searchEmptyState(String message) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(28, 28, 28, 32),
      child: Column(
        children: [
          Icon(Icons.search_off_rounded, size: 34, color: scheme.onSurfaceVariant),
          const SizedBox(height: 10),
          Text(message, textAlign: TextAlign.center, style: TextStyle(color: scheme.onSurface, fontWeight: FontWeight.w800)),
          const SizedBox(height: 5),
          Text('Coba judul saja, nama artis saja, atau ubah kata pencarian.', textAlign: TextAlign.center, style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _hubChannelCard(YoutubeChannelSearchResult channel) {
    final hasThumbnail = channel.thumbnailUrl.isNotEmpty;
    return SizedBox(
      width: 160,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          if (_artistChannelMode) {
            _openArtistCatalogue(channel);
          } else {
            _handleControllerOpenChannel(
              channel.channelId,
              channel.title,
              channel.thumbnailUrl,
            );
          }
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircleAvatar(
                radius: 28,
                backgroundImage: hasThumbnail ? NetworkImage(channel.thumbnailUrl) : null,
                child: hasThumbnail ? null : const Icon(Icons.person_rounded),
              ),
              const SizedBox(height: 6),
              Text(
                channel.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
              ),
              const SizedBox(height: 2),
              Text(
                _artistChannelMode ? 'Lihat daftar lagu' : 'Buka channel',
                style: const TextStyle(fontSize: 10.5),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// -----------------------------------------------------------------------------
// Floating dock
// -----------------------------------------------------------------------------

class _DockItem {
  const _DockItem(this.label, this.icon, this.selectedIcon);

  final String label;
  final IconData icon;
  final IconData selectedIcon;
}

/// Urutan harus sama dengan [_YoutubeSection]: home, explore, samples, library.
const List<_DockItem> _dockItems = [
  _DockItem('Beranda', Icons.home_outlined, Icons.home_rounded),
  _DockItem('Jelajah', Icons.explore_outlined, Icons.explore_rounded),
  _DockItem('Radio', Icons.radio_outlined, Icons.radio_rounded),
  _DockItem('Koleksi', Icons.library_music_outlined, Icons.library_music_rounded),
];

/// Seberapa besar ikon [index] diperbesar oleh lensa pada posisi [visualIndex].
double _dockMagnification(
  int index,
  double visualIndex,
  bool dragging,
  int activeIndex,
) {
  if (!dragging) return index == activeIndex ? 0.22 : 0.0;
  final distance = (index - visualIndex).abs();
  return (1.0 - distance / 1.35).clamp(0.0, 1.0).toDouble();
}

String _formatHubError(Object error) {
  final message = error.toString().replaceFirst('Bad state: ', '').trim();
  return message.isEmpty ? 'Permintaan gagal. Periksa koneksi lalu coba lagi.' : message;
}

/// Floating editorial dock. Drag state stays inside this widget so moving the
/// selected capsule does not rebuild the whole music feed on every pointer tick.
class _EditorialFloatingDock extends StatefulWidget {
  const _EditorialFloatingDock({
    required this.selectedIndex,
    required this.onSelect,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelect;

  @override
  State<_EditorialFloatingDock> createState() => _EditorialFloatingDockState();
}

class _EditorialFloatingDockState extends State<_EditorialFloatingDock> {
  double? _dragX;

  int get _lastIndex => _dockItems.length - 1;

  double _clampDragX(double x, double cellWidth, double maxWidth) =>
      x.clamp(cellWidth * 0.5, maxWidth - cellWidth * 0.5).toDouble();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 62,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final maxWidth = constraints.maxWidth;
          final cellWidth = maxWidth / _dockItems.length;
          final activeIndex = widget.selectedIndex;
          final dragX = _dragX;
          final dragging = dragX != null;
          final visualIndex = dragging
              ? (dragX / cellWidth - 0.5).clamp(0.0, _lastIndex.toDouble()).toDouble()
              : activeIndex.toDouble();
          final activeLeft = (visualIndex * cellWidth + 4).clamp(0.0, maxWidth - cellWidth + 4).toDouble();
          final scheme = Theme.of(context).colorScheme;
          final reduceMotion = MediaQuery.of(context).disableAnimations;

          return GestureDetector(
            behavior: HitTestBehavior.opaque,
            onHorizontalDragStart: (details) => setState(() => _dragX = _clampDragX(details.localPosition.dx, cellWidth, maxWidth)),
            onHorizontalDragUpdate: (details) => setState(() {
              final nextX = (_dragX ?? ((activeIndex + 0.5) * cellWidth)) + details.delta.dx;
              _dragX = _clampDragX(nextX, cellWidth, maxWidth);
            }),
            onHorizontalDragEnd: (_) {
              final endX = _dragX;
              final target = endX == null ? activeIndex : (endX / cellWidth - 0.5).round().clamp(0, _lastIndex).toInt();
              setState(() => _dragX = null);
              if (target != widget.selectedIndex) widget.onSelect(target);
            },
            onHorizontalDragCancel: () => setState(() => _dragX = null),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(19),
              child: BackdropFilter(
                filter: ui.ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                child: Container(
                  decoration: BoxDecoration(
                    color: scheme.surface.withValues(alpha: Theme.of(context).brightness == Brightness.dark ? 0.76 : 0.86),
                    borderRadius: BorderRadius.circular(19),
                    border: Border.all(color: scheme.outlineVariant.withValues(alpha: 0.72)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: Theme.of(context).brightness == Brightness.dark ? 0.16 : 0.045),
                        blurRadius: 22,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Stack(
                fit: StackFit.expand,
                children: [
                  AnimatedPositioned(
                    duration: dragging || reduceMotion ? Duration.zero : const Duration(milliseconds: 220),
                    curve: Curves.easeOutCubic,
                    left: activeLeft,
                    top: 5,
                    bottom: 5,
                    width: cellWidth - 8,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(color: scheme.primaryContainer.withValues(alpha: 0.72), borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      for (var i = 0; i < _dockItems.length; i++)
                        Expanded(
                          child: _FlowDockDestination(
                            label: _dockItems[i].label,
                            icon: _dockItems[i].icon,
                            selectedIcon: _dockItems[i].selectedIcon,
                            selected: dragging ? (i - visualIndex).abs() < 0.48 : activeIndex == i,
                            magnification: _dockMagnification(i, visualIndex, dragging, activeIndex),
                            onTap: () => widget.onSelect(i),
                          ),
                        ),
                    ],
                  ),
                ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Destination untuk floating dock: ikon dan label ikut bergerak halus,
/// bukan hanya mengganti warna NavigationBar standar. Permukaan "terpilih"
/// disediakan oleh penanda warna yang bergerak di belakang destination.
class _FlowDockDestination extends StatelessWidget {
  const _FlowDockDestination({
    required this.label,
    required this.icon,
    required this.selectedIcon,
    required this.selected,
    required this.magnification,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final IconData selectedIcon;
  final bool selected;
  final double magnification;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final animationDuration = MediaQuery.of(context).disableAnimations
        ? Duration.zero
        : const Duration(milliseconds: 130);
    return Semantics(
      button: true,
      selected: selected,
      label: label,
      child: Tooltip(
        message: label,
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(14),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 6),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedScale(
                    scale: 1.0 + magnification * 0.18,
                    duration: animationDuration,
                    curve: Curves.easeOutCubic,
                    child: Icon(
                      selected ? selectedIcon : icon,
                      size: 21,
                      color: selected ? scheme.primary : scheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 3),
                  AnimatedDefaultTextStyle(
                    duration: animationDuration,
                    curve: Curves.easeOut,
                    style: TextStyle(
                      fontSize: selected ? 9.7 : 9.2,
                      height: 1.1,
                      fontWeight: selected ? FontWeight.w900 : FontWeight.w600,
                      color: selected ? scheme.primary : scheme.onSurfaceVariant,
                      letterSpacing: 0,
                    ),
                    child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
