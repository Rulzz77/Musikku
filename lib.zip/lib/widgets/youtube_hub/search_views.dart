part of '../youtube_hub.dart';

// The state extensions share private UI logic; State.setState is used by this library.
// ignore_for_file: invalid_use_of_protected_member

extension _YoutubeHubSearchViews on _YoutubeHubState {
  Future<void> _openSearch() async {
    if (!mounted) return;
    final picked = await Navigator.of(context).push<YoutubeSearchRequest>(
      MaterialPageRoute(
        builder: (_) => YoutubeSearchPage(
          suggestService: _suggestService,
          initialQuery: _query,
          history: _searchHistory,
          onDeleteHistory: _deleteSearchHistory,
        ),
      ),
    );
    if (picked == null || picked.query.trim().isEmpty || !mounted) return;
    setState(() {
      _activeChip = -1;
      _activeSearchFilters = picked.filters;
      _searchResultsTab = _SearchResultsTab.all;
    });
    _searchController.text = picked.query.trim();
    await _search();
  }

  Future<void> _searchChannelsForCurrentQuery({bool artistMode = false}) async {
    final query = _query.trim();
    if (!mounted || query.isEmpty || _channelSearchLoading) return;
    final requestId = _searchRequestId;
    if (artistMode) {
      // Hasil pencarian sudah memuat channel artisnya (mis. 3+ lagu dari
      // channel yang namanya cocok). Pakai itu langsung: instan dan tanpa
      // request search.list tambahan.
      final local = _artistChannelsFromResults(query);
      if (local.isNotEmpty) {
        setState(() {
          _searchChannels = local;
          _artistChannelMode = true;
        });
        return;
      }
    }
    setState(() {
      _channelSearchLoading = true;
      _artistChannelMode = artistMode;
    });
    try {
      var channels = await _searchService.searchChannels(query);
      if (!mounted || requestId != _searchRequestId || query != _query.trim()) return;
      if (artistMode) {
        // Automatic artist discovery only keeps channels whose names actually
        // match the query (e.g. "Raisa Official" for "Raisa"). This avoids
        // showing unrelated channels and avoids a second search for ordinary
        // song/genre queries.
        channels = channels
            .where((channel) => _channelNameMatchesArtistQuery(channel.title, query))
            .toList(growable: false);

        // Dotted stage names can be indexed without punctuation or spaces by
        // YouTube (NDX A.K.A. -> NDXAKA). Retry aliases only when the first
        // channel search returned no verified name match.
        if (channels.isEmpty) {
          final normalized = _normalizeArtistChannelName(query);
          final compact = normalized.replaceAll(' ', '');
          final aliases = <String>{normalized, compact}
              .where((value) => value.isNotEmpty && value != query.toLowerCase())
              .toList(growable: false);
          for (final alias in aliases) {
            try {
              final aliasResults = await _searchService.searchChannels(alias);
              if (!mounted || requestId != _searchRequestId || query != _query.trim()) return;
              final matched = aliasResults
                  .where((channel) => _channelNameMatchesArtistQuery(channel.title, query))
                  .toList(growable: false);
              if (matched.isNotEmpty) {
                channels = matched;
                break;
              }
            } catch (aliasError) {
              debugPrint('ARTIST CHANNEL ALIAS SEARCH FAILED [$alias]: $aliasError');
            }
          }
        }
      }
      setState(() {
        _searchChannels = channels.take(8).toList(growable: false);
        _artistChannelMode = artistMode && _searchChannels.isNotEmpty;
      });
    } catch (error) {
      if (!mounted || requestId != _searchRequestId || query != _query.trim()) return;
      setState(() {
        _artistChannelMode = false;
        _error = error is YoutubeSearchException
            ? error.message
            : 'Pencarian channel gagal. Coba lagi nanti.';
      });
    } finally {
      if (mounted && requestId == _searchRequestId && query == _query.trim()) {
        setState(() => _channelSearchLoading = false);
      }
    }
  }

  String _normalizeArtistChannelName(String value) => value
      .toLowerCase()
      .replaceAll(
        RegExp(r'\b(?:official(?:\s+music)?(?:\s+channel)?|vevo|topic|music\s+channel|channel)\b', caseSensitive: false),
        ' ',
      )
      .replaceAll(RegExp(r'[^a-z0-9\u0080-\uFFFF\s]'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();

  bool _channelNameMatchesArtistQuery(String channelTitle, String query) {
    final normalizedQuery = _normalizeArtistChannelName(query);
    final normalizedChannel = _normalizeArtistChannelName(channelTitle);
    if (normalizedQuery.isEmpty || normalizedChannel.isEmpty) return false;
    if (normalizedChannel == normalizedQuery ||
        normalizedChannel.startsWith('$normalizedQuery ') ||
        normalizedQuery.startsWith('$normalizedChannel ')) {
      return true;
    }
    // Toleran terhadap spasi dan kata tambahan: "sheila on 7" ~ "SheilaOn7",
    // "hindia" ~ "Hindia Band".
    final compactQuery = normalizedQuery.replaceAll(' ', '');
    final compactChannel = normalizedChannel.replaceAll(' ', '');
    if (compactQuery.length >= 3 &&
        compactChannel.length >= 3 &&
        (compactChannel == compactQuery ||
            compactChannel.startsWith(compactQuery) ||
            compactQuery.startsWith(compactChannel))) {
      return true;
    }
    final channelTokens = normalizedChannel.split(' ').toSet();
    final queryTokens =
        normalizedQuery.split(' ').where((t) => t.length >= 2).toList();
    return queryTokens.isNotEmpty &&
        queryTokens.every(channelTokens.contains);
  }

  /// Turunkan kartu artis dari hasil pencarian yang sudah ada. Satu hasil
  /// dari channel yang namanya cocok sudah cukup karena hasil tersebut sudah
  /// melewati filter musik dan pencarian channel tidak perlu menunggu 3 lagu.
  List<YoutubeChannelSearchResult> _artistChannelsFromResults(String query) {
    final counts = <String, int>{};
    final samples = <String, YoutubeSearchResult>{};
    for (final video in _searchResults.take(20)) {
      if (video.isLocal || video.channelTitle.trim().isEmpty) continue;
      final key = video.channelId.isNotEmpty
          ? video.channelId
          : _normalizeArtistChannelName(video.channelTitle);
      if (key.isEmpty) continue;
      counts[key] = (counts[key] ?? 0) + 1;
      samples.putIfAbsent(key, () => video);
    }
    final ranked = counts.entries
        .where((entry) =>
            entry.value >= 1 &&
            _channelNameMatchesArtistQuery(
              samples[entry.key]!.channelTitle,
              query,
            ))
        .toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return ranked.take(3).map((entry) {
      final sample = samples[entry.key]!;
      return YoutubeChannelSearchResult(
        channelId: sample.channelId,
        title: sample.channelTitle,
        description: '',
        thumbnailUrl: '',
      );
    }).toList(growable: false);
  }

  bool _isLikelyArtistNameSearch(String query, List<YoutubeSearchResult> videos) {
    final trimmed = query.trim();
    if (trimmed.isEmpty || trimmed.length > 36) return false;
    final words = _normalizeArtistChannelName(trimmed)
        .split(RegExp(r'\s+'))
        .where((word) => word.length > 1 ||
            !RegExp(r'^[a-z0-9]+$').hasMatch(word))
        .toList(growable: false);
    // Ignore dotted initials (e.g. NDX A.K.A.) when deciding whether this
    // looks like a performer query; the compact channel comparison handles it.
    if (words.isEmpty || words.length > 2) return false;
    if (RegExp(
      r'\b(?:lagu|musik|music|song|songs|official|video|mv|lyrics?|lirik|audio|cover|remix|album|playlist|radio|mix|karaoke|soundtrack|terbaru|latest|hits|popular|populer)\b',
      caseSensitive: false,
    ).hasMatch(trimmed)) {
      return false;
    }

    final normalizedQuery = _normalizeArtistChannelName(trimmed);
    const genericGenreQueries = <String>{
      'pop', 'rock', 'jazz', 'metal', 'indie', 'dangdut', 'koplo', 'dj',
      'remix', 'k pop', 'hip hop', 'lofi', 'lo fi', 'radio', 'soundtrack',
      'instrumental', 'karaoke', 'chill', 'blues', 'reggae', 'classical',
      'country', 'folk', 'edm', 'house', 'techno', 'trance', 'ambient',
      'pop indonesia', 'rock indonesia', 'lagu inggris', 'lagu indonesia',
      'lagu jawa', 'lagu akustik', 'dangdut koplo', 'dj remix',
    };
    if (genericGenreQueries.contains(normalizedQuery) ||
        RegExp(r'\b(?:indonesia|inggris|english|jawa|akustik|acoustic)\b', caseSensitive: false)
            .hasMatch(normalizedQuery)) {
      return false;
    }
    if (normalizedQuery.isEmpty) return false;
    // Don't spend a channel-search request on obvious exact track-title queries.
    final exactSongTitle = videos.take(12).any((video) =>
        _normalizeArtistChannelName(video.title) == normalizedQuery);
    return !exactSongTitle;
  }

  void _openArtistCatalogue(YoutubeChannelSearchResult channel) {
    if (!mounted) return;
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ArtistPage(
          artist: _query.trim().isNotEmpty ? _query.trim() : channel.title,
          channelId: channel.channelId,
          searchService: _searchService,
          initialSearchResults: _searchResults,
          onPlayList: widget.onPlayFromList,
          onPlay: (video) => unawaited(widget.onPlay(video)),
          onLongPress: widget.onShowVideoMenu,
        ),
      ),
    );
  }

  Future<void> _deleteSearchHistory(String? query) async {
    final updated = query == null
        ? <String>[]
        : _searchHistory
            .where((item) => item.toLowerCase() != query.toLowerCase())
            .toList(growable: false);
    await _storage.saveHistory(updated);
    if (!mounted) return;
    setState(() => _searchHistory = updated);
  }

  void _clearSearch() {
    _searchRequestId++;
    _searchController.clear();
    setState(() {
      _activeChip = 0;
      _loading = false;
      _query = '';
      _searchResults = const [];
      _searchChannels = const [];
      _channelSearchLoading = false;
      _artistChannelMode = false;
      _searchResultsTab = _SearchResultsTab.all;
    });
    unawaited(_loadHome());
  }

  /// Set state loading pencarian langsung agar indikator muncul seketika.
  /// _query diisi sebelum request selesai supaya hasil pencarian responsif.
  /// layar hasil + indikator loading tampil seketika.
  Future<void> _search({bool keepResults = false}) async {
    final query = _searchController.text.trim();
    widget.onSearchQueryChanged?.call(query);
    final requestId = ++_searchRequestId;

    if (query.isEmpty) {
      setState(() {
        _activeChip = 0;
        _query = '';
          _searchResults = const [];
        _searchChannels = const [];
        _channelSearchLoading = false;
        _artistChannelMode = false;
        _searchResultsTab = _SearchResultsTab.all;
        _section = _YoutubeSection.home;
        _loading = false;
      });
      await _loadHome();
      return;
    }

    setState(() {
      _query = query;
      if (!keepResults) {
        _searchResults = const [];
      }
      // The secondary channel lookup is deferred until we know whether this
      // query looks like an artist name, to avoid extra requests for songs/genres.
      _searchChannels = const [];
      _channelSearchLoading = false;
      _artistChannelMode = false;
      _searchResultsTab = _SearchResultsTab.all;
      _section = _YoutubeSection.home;
      _loading = true;
      _error = '';
    });

    try {
      final filters = _activeSearchFilters;
      final searchQuery = filters.buildQuery(query);
      final videos = await _searchService.search(searchQuery);
      if (!mounted || requestId != _searchRequestId) return;

      final updatedHistory = List<String>.from(_searchHistory)
        ..removeWhere((item) => item.toLowerCase() == query.toLowerCase())
        ..insert(0, query);
      if (updatedHistory.length > StorageService.maxHistory) {
        updatedHistory.removeRange(StorageService.maxHistory, updatedHistory.length);
      }

      final visibleVideos = filters.apply(videos).take(30).toList(growable: false);
      setState(() {
        _searchResults = visibleVideos;
        _searchHistory = updatedHistory;
      });
      unawaited(_storage.saveHistory(updatedHistory));

      // Artist-name searches get an artist entry automatically, like a music
      // catalogue. Song titles and genre queries keep the single search.list
      // request path; channel discovery is only triggered for likely names.
      if (_isLikelyArtistNameSearch(query, visibleVideos)) {
        unawaited(_searchChannelsForCurrentQuery(artistMode: true));
      } else if (query.split(RegExp(r'\s+')).length <= 4) {
        // Nama artis 3-4 kata ("Sheila On 7", "Hindia Band"): hanya jalur
        // gratis dari hasil yang sudah ada, tanpa request tambahan.
        final local = _artistChannelsFromResults(query);
        if (local.isNotEmpty) {
          setState(() {
            _searchChannels = local;
            _artistChannelMode = true;
          });
        }
      }
    } catch (e) {
      if (!mounted || requestId != _searchRequestId) return;
      debugPrint('YOUTUBE SEARCH ERROR: $e');
      setState(() {
        _error = e is YoutubeSearchException ? e.message : _formatHubError(e);
      });
    } finally {
      if (mounted && requestId == _searchRequestId) {
        setState(() => _loading = false);
      }
    }
  }

  List<YoutubeSearchResult> _sampleVideos() {
    final result = <YoutubeSearchResult>[];
    final seen = <String>{};
    for (final video in [..._trending, ...widget.recentlyPlayed]) {
      if (video.videoId.isNotEmpty &&
          !video.isLive &&
          !video.isUpcoming &&
          YoutubeSearchService.isMusicCandidate(video) &&
          seen.add(video.videoId)) {
        result.add(video);
      }
    }
    return result;
  }

  Future<void> _loadExploreCategory(String category, {bool force = false}) async {
    final requestSequence = ++_exploreRequestSequence;
    if (category == 'Sedang tren') {
      setState(() {
        _exploreCategory = category;
        _exploreResults = _trending;
        _exploreError = _feedError;
        _exploreLoading = false;
      });
      if (_trending.isEmpty && !_feedLoading) {
        await _loadHome(force: force);
        if (!mounted ||
            requestSequence != _exploreRequestSequence ||
            _exploreCategory != category) {
          return;
        }
        setState(() {
          _exploreResults = _trending;
          _exploreError = _feedError;
          _exploreLoading = false;
        });
      }
      return;
    }
    if (!force && category == _exploreCategory && _exploreResults.isNotEmpty) {
      if (mounted && _exploreLoading) setState(() => _exploreLoading = false);
      return;
    }
    final query = _YoutubeHubState._exploreQueries[category];
    if (query == null) return;
    setState(() {
      _exploreCategory = category;
      _exploreResults = const [];
      _exploreLoading = true;
      _exploreError = '';
    });
    try {
      var results = await _searchService.search(query);

      // Dangdut sering diunggah melalui label/artist channels yang tidak selalu
      // memakai kata "official" di judul. Cari variasi tambahan hanya saat hasil
      // pertama sedikit, lalu gabungkan unik; semua hasil melewati kebijakan
      // musik bersama yang menolak cover, karaoke, AI, dan konten nonmusik jelas.
      if ((category == 'Dangdut' || category == 'Dangdut/Koplo') &&
          results.length < 6) {
        final fallbackQueries = category == 'Dangdut'
            ? const <String>[
                'lagu dangdut Indonesia',
                'dangdut Indonesia audio',
                'NAGASWARA dangdut music',
              ]
            : const <String>[
                'lagu dangdut koplo Indonesia',
                'dangdut koplo Indonesia music',
                'Milady Record dangdut koplo',
              ];
        final combined = <String, YoutubeSearchResult>{
          for (final video in results)
            if (video.videoId.isNotEmpty) video.videoId: video,
        };
        for (final fallbackQuery in fallbackQueries) {
          try {
            final extra = await _searchService.search(fallbackQuery);
            for (final video in extra) {
              if (video.videoId.isNotEmpty &&
                  !video.isLive &&
                  !video.isUpcoming) {
                combined.putIfAbsent(video.videoId, () => video);
              }
            }
          } catch (_) {
            // Pakai hasil utama yang ada jika pencarian cadangan gagal.
          }
          if (combined.length >= 10) break;
        }
        results = combined.values.toList(growable: false);
      }

      if (!mounted ||
          requestSequence != _exploreRequestSequence ||
          _exploreCategory != category) {
        return;
      }
      setState(() {
        _exploreResults = results.where((video) => !video.isLive && !video.isUpcoming).toList(growable: false);
        _exploreError = '';
      });
    } catch (error) {
      if (!mounted ||
          requestSequence != _exploreRequestSequence ||
          _exploreCategory != category) {
        return;
      }
      setState(() {
        _exploreResults = const [];
        _exploreError = error is YoutubeSearchException
            ? error.message
            : 'Belum bisa memuat genre ini. Periksa koneksi lalu coba lagi.';
      });
    } finally {
      if (mounted &&
          requestSequence == _exploreRequestSequence &&
          _exploreCategory == category) {
        setState(() => _exploreLoading = false);
      }
    }
  }

  Future<void> _startMoodRadio(String mood) async {
    if (_radioMoodLoading || widget.onStartRadio == null) return;
    const queries = <String, String>{
      'Chill': 'lagu chill Indonesia santai',
      'Sad': 'lagu galau Indonesia sedih',
      'Happy': 'lagu ceria Indonesia happy',
      'Energetic': 'lagu semangat Indonesia upbeat',
      'Focus': 'instrumental focus music',
      'Relax': 'lagu santai Indonesia akustik',
    };
    final query = queries[mood];
    if (query == null) return;
    setState(() {
      _radioMoodLoading = true;
      _radioMoodLoadingName = mood;
    });
    try {
      final results = await _searchService.search(query);
      if (!mounted) return;
      final candidates = results
          .where((video) =>
              video.videoId.isNotEmpty &&
              !video.isLocal &&
              !video.isLive &&
              !video.isUpcoming &&
              YoutubeSearchService.isMusicCandidate(video))
          .toList(growable: false);
      if (candidates.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Radio $mood belum menemukan lagu. Coba lagi.')),
        );
        return;
      }
      await widget.onStartRadio!(candidates.first);
    } catch (error) {
      if (!mounted) return;
      final message = error is YoutubeSearchException
          ? error.message
          : 'Radio $mood belum bisa dimulai. Periksa koneksi lalu coba lagi.';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    } finally {
      if (mounted) {
        setState(() {
          _radioMoodLoading = false;
          _radioMoodLoadingName = '';
        });
      }
    }
  }

  Widget _radioMoodGrid(ColorScheme scheme) {
    const moods = <({String name, String subtitle, IconData icon})>[
      (name: 'Chill', subtitle: 'Santai dan tenang', icon: Icons.nightlight_round),
      (name: 'Sad', subtitle: 'Lagu penuh rasa', icon: Icons.cloud_outlined),
      (name: 'Happy', subtitle: 'Bikin suasana cerah', icon: Icons.wb_sunny_outlined),
      (name: 'Energetic', subtitle: 'Musik penuh energi', icon: Icons.bolt_rounded),
      (name: 'Focus', subtitle: 'Temani konsentrasi', icon: Icons.center_focus_strong),
      (name: 'Relax', subtitle: 'Lepaskan penat', icon: Icons.spa_outlined),
    ];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: moods.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          mainAxisExtent: 84,
        ),
        itemBuilder: (context, index) {
          final mood = moods[index];
          final loading = _radioMoodLoading && _radioMoodLoadingName == mood.name;
          return Material(
            color: scheme.surfaceContainerLow,
            borderRadius: BorderRadius.circular(17),
            clipBehavior: Clip.antiAlias,
            child: InkWell(
              onTap: _radioMoodLoading ? null : () => unawaited(_startMoodRadio(mood.name)),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                child: Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: scheme.primaryContainer,
                        borderRadius: BorderRadius.circular(13),
                      ),
                      child: loading
                          ? Padding(
                              padding: const EdgeInsets.all(12),
                              child: CircularProgressIndicator(strokeWidth: 2, color: scheme.onPrimaryContainer),
                            )
                          : Icon(mood.icon, color: scheme.onPrimaryContainer, size: 21),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(mood.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: scheme.onSurface, fontSize: 13, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 3),
                          Text(mood.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 9.5)),
                        ],
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios_rounded, size: 13, color: scheme.onSurfaceVariant),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  List<Widget> _samplesView() {
    final videos = _sampleVideos();
    final recentRadioSeeds = widget.recentlyPlayed
        .where((video) =>
            video.videoId.isNotEmpty &&
            !video.isLocal &&
            !video.isLive &&
            !video.isUpcoming &&
            YoutubeSearchService.isMusicCandidate(video))
        .take(8)
        .toList(growable: false);
    YoutubeSearchResult? seedVideo;
    for (final video in videos) {
      if (video.videoId == widget.currentVideoId) {
        seedVideo = video;
        break;
      }
    }
    final radioSeed = seedVideo ?? (videos.isEmpty ? null : videos.first);
    final scheme = Theme.of(context).colorScheme;
    return [
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 15, 18, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(color: scheme.primaryContainer, borderRadius: BorderRadius.circular(12)),
                    child: Icon(Icons.radio_rounded, color: scheme.onPrimaryContainer, size: 20),
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('DISCOVERY STATION', style: TextStyle(color: scheme.primary, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.7)),
                        const SizedBox(height: 3),
                        Text('Ikuti alur musikmu', style: TextStyle(color: scheme.onSurface, fontSize: 23, height: 1, fontWeight: FontWeight.w900, letterSpacing: -0.8)),
                      ],
                    ),
                  ),
                  IconButton.filledTonal(
                    onPressed: _feedLoading ? null : () => unawaited(_loadHome(force: true)),
                    tooltip: 'Segarkan radio',
                    icon: const Icon(Icons.refresh_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 15),
              Text(
                'Mulai dari satu lagu. MusikKu akan menyusun perjalanan berikutnya berdasarkan gaya, bahasa, dan artis yang berkaitan.',
                style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12, height: 1.45),
              ),
              const SizedBox(height: 15),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: radioSeed == null || widget.onStartRadio == null ? null : () => unawaited(widget.onStartRadio!(radioSeed)),
                      icon: const Icon(Icons.radio_rounded, size: 18),
                      label: const Text('Mulai radio'),
                      style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 13)),
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: videos.isEmpty ? null : () => unawaited(widget.onPlayFromList(videos.first, videos)),
                      icon: const Icon(Icons.shuffle_rounded, size: 18),
                      label: const Text('Putar mix'),
                      style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 13)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 2, 18, 10),
          child: Row(
            children: [
              Expanded(child: Text('Radio berdasarkan mood', style: TextStyle(color: scheme.onSurface, fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: -0.35))),
              Text('Pilih suasana', style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 10, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
      SliverToBoxAdapter(child: _radioMoodGrid(scheme)),
      if (recentRadioSeeds.isNotEmpty)
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.only(top: 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 0, 18, 9),
                  child: Text('Mulai dari riwayatmu', style: TextStyle(color: scheme.onSurface, fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: -0.35)),
                ),
                SizedBox(
                  height: 142,
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 18),
                    scrollDirection: Axis.horizontal,
                    itemCount: recentRadioSeeds.length,
                    separatorBuilder: (_, _) => const SizedBox(width: 11),
                    itemBuilder: (context, index) {
                      final track = recentRadioSeeds[index];
                      return SizedBox(
                        width: 104,
                        child: InkWell(
                          borderRadius: BorderRadius.circular(13),
                          onTap: widget.onStartRadio == null ? null : () => unawaited(widget.onStartRadio!(track)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: AlbumArtworkImage(track: track, width: 104, height: 104, fit: BoxFit.cover),
                              ),
                              const SizedBox(height: 6),
                              Text(track.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: scheme.onSurface, fontSize: 10.5, fontWeight: FontWeight.w800)),
                              Text(track.channelTitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 9)),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      if (videos.isEmpty && _feedLoading)
        const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(28), child: Center(child: CircularProgressIndicator())))
      else if (videos.isEmpty)
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Material(
              color: scheme.surfaceContainerLow,
              borderRadius: BorderRadius.circular(18),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Icon(Icons.radar_rounded, size: 38, color: scheme.primary),
                    const SizedBox(height: 10),
                    Text('Radio belum tersedia', style: TextStyle(color: scheme.onSurface, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 6),
                    Text(_feedError.isNotEmpty ? _feedError : 'Muat rekomendasi musik terlebih dahulu.', textAlign: TextAlign.center, style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12)),
                    const SizedBox(height: 12),
                    FilledButton.icon(onPressed: () => unawaited(_loadHome(force: true)), icon: const Icon(Icons.refresh_rounded), label: const Text('Muat ulang')),
                  ],
                ),
              ),
            ),
          ),
        )
      else ...[
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 9),
            child: Row(
              children: [
                Container(width: 4, height: 20, decoration: BoxDecoration(color: scheme.primary, borderRadius: BorderRadius.circular(4))),
                const SizedBox(width: 9),
                Expanded(child: Text('Mulai dari lagu ini', style: TextStyle(color: scheme.onSurface, fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: -0.45))),
                Text('${videos.length} pilihan', style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 10, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 244,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              scrollDirection: Axis.horizontal,
              itemCount: min(videos.length, 12).toInt(),
              separatorBuilder: (_, _) => const SizedBox(width: 12),
              itemBuilder: (context, index) => _sampleCard(videos[index]),
            ),
          ),
        ),
        _sectionHeader('Lanjutkan eksplorasi'),
        SliverList.builder(
          itemCount: videos.length,
          itemBuilder: (context, index) => _videoCard(videos[index]),
        ),
      ],
      const SliverToBoxAdapter(child: SizedBox(height: 20)),
    ];
  }

  List<Widget> _exploreView() {
    final scheme = Theme.of(context).colorScheme;
    final exploreSource = _exploreCategory == 'Sedang tren' ? _trending : _exploreResults;
    final shownResults = exploreSource.where((video) => YoutubeSearchService.isMusicCandidate(video)).toList(growable: false);
    final shownLoading = _exploreCategory == 'Sedang tren' ? _feedLoading : _exploreLoading;
    final shownError = _exploreCategory == 'Sedang tren' ? _feedError : _exploreError;

    IconData genreIcon(String category) => switch (category) {
      'Sedang tren' => Icons.trending_up_rounded,
      'Pop Indonesia' => Icons.mic_rounded,
      'Dangdut' || 'Dangdut/Koplo' => Icons.music_note_rounded,
      'K-Pop' => Icons.auto_awesome_rounded,
      'Hip-hop' => Icons.graphic_eq_rounded,
      'Rock' => Icons.album_rounded,
      'Jazz' => Icons.graphic_eq_rounded,
      'Lo-fi' => Icons.nightlight_round,
      'Musik religi' => Icons.favorite_rounded,
      _ => Icons.headphones_rounded,
    };

    return [
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('FIND YOUR NEXT SOUND', style: TextStyle(color: scheme.primary, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.8)),
              const SizedBox(height: 5),
              Text('Jelajahi musik', style: TextStyle(color: scheme.onSurface, fontSize: 27, height: 1, fontWeight: FontWeight.w900, letterSpacing: -1.1)),
              const SizedBox(height: 7),
              Text('Pilih suasana, bukan sekadar mencari judul.', style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12)),
            ],
          ),
        ),
      ),
      SliverToBoxAdapter(
        child: SizedBox(
          height: 52,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
            scrollDirection: Axis.horizontal,
            itemCount: _YoutubeHubState._exploreCategories.length,
            separatorBuilder: (_, _) => const SizedBox(width: 8),
            itemBuilder: (context, index) {
              final category = _YoutubeHubState._exploreCategories[index];
              final selected = _exploreCategory == category;
              return ChoiceChip(
                avatar: Icon(genreIcon(category), size: 15, color: selected ? scheme.onPrimary : scheme.onSurfaceVariant),
                label: Text(category),
                selected: selected,
                showCheckmark: false,
                onSelected: (_) { if (!selected) unawaited(_loadExploreCategory(category)); },
                backgroundColor: scheme.surfaceContainerLow,
                selectedColor: scheme.primary,
                side: BorderSide(color: selected ? scheme.primary : scheme.outlineVariant.withValues(alpha: 0.65)),
                labelStyle: TextStyle(color: selected ? scheme.onPrimary : scheme.onSurface, fontSize: 11, fontWeight: FontWeight.w800),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              );
            },
          ),
        ),
      ),
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 11, 18, 14),
          child: Container(
            padding: const EdgeInsets.fromLTRB(16, 15, 14, 15),
            decoration: BoxDecoration(
              color: scheme.primaryContainer,
              borderRadius: const BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20), bottomRight: Radius.circular(20), bottomLeft: Radius.circular(5)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('SEDANG KAMU JELAJAHI', style: TextStyle(color: scheme.onPrimaryContainer.withValues(alpha: 0.7), fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 1.3)),
                      const SizedBox(height: 5),
                      Text(_exploreCategory, style: TextStyle(color: scheme.onPrimaryContainer, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: -0.45)),
                      const SizedBox(height: 4),
                      Text('Pilihan lagu yang dikurasi dari genre ini', style: TextStyle(color: scheme.onPrimaryContainer.withValues(alpha: 0.74), fontSize: 10.5)),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                Icon(genreIcon(_exploreCategory), size: 42, color: scheme.onPrimaryContainer.withValues(alpha: 0.82)),
              ],
            ),
          ),
        ),
      ),
      if (shownLoading && shownResults.isEmpty)
        const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(28), child: Center(child: CircularProgressIndicator())))
      else if (shownError.isNotEmpty && shownResults.isEmpty)
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Material(
              color: scheme.surfaceContainerLow,
              borderRadius: BorderRadius.circular(16),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Icon(Icons.wifi_off_rounded, color: scheme.primary, size: 36),
                    const SizedBox(height: 10),
                    Text('Musik belum bisa dimuat', style: TextStyle(color: scheme.onSurface, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 6),
                    Text(shownError, textAlign: TextAlign.center, style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12)),
                    const SizedBox(height: 12),
                    FilledButton.icon(onPressed: () => unawaited(_loadExploreCategory(_exploreCategory, force: true)), icon: const Icon(Icons.refresh_rounded), label: const Text('Coba lagi')),
                  ],
                ),
              ),
            ),
          ),
        )
      else if (shownResults.isEmpty)
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(24), child: Center(child: Text('Belum ada hasil untuk genre ini.', style: TextStyle(color: scheme.onSurfaceVariant)))))
      else ...[
        _sectionHeader('Pilihan untukmu'),
        SliverList.builder(itemCount: shownResults.length, itemBuilder: (context, index) => _videoCard(shownResults[index])),
      ],
      const SliverToBoxAdapter(child: SizedBox(height: 20)),
    ];
  }

  Widget _chipRow() {
    const labels = ['Semua', 'Populer', 'Terbaru'];
    final scheme = Theme.of(context).colorScheme;
    return SliverToBoxAdapter(
      child: SizedBox(
        height: 46,
        child: ListView.separated(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          scrollDirection: Axis.horizontal,
          itemCount: labels.length,
          separatorBuilder: (_, _) => const SizedBox(width: 8),
          itemBuilder: (context, index) {
            final selected = _query.isEmpty && _activeChip == index;
            return ChoiceChip(
              label: Text(labels[index]),
              selected: selected,
              showCheckmark: false,
              visualDensity: VisualDensity.compact,
              selectedColor: scheme.primary,
              backgroundColor: scheme.surfaceContainerHigh.withValues(alpha: 0.9),
              side: BorderSide.none,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(999),
              ),
              labelStyle: TextStyle(
                color: selected ? scheme.onPrimary : scheme.onSurfaceVariant,
                fontSize: 12.5,
                fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
              ),
              onSelected: (_) {
                if (index == 0) {
                  _clearSearch();
                } else {
                  unawaited(_selectChip(index));
                }
              },
            );
          },
        ),
      ),
    );
  }
}